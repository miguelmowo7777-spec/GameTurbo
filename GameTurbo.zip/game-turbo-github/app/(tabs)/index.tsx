import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useEffect, useMemo, useState, type ComponentProps, type ReactNode } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { GameEntry } from '@/components/GameEntry';
import { GamePanel } from '@/components/GamePanel';

type Screen = 'home' | 'games' | 'settings' | 'monitor' | 'launch' | 'panel';
type Mode = 'Equilibrado' | 'Rendimiento' | 'Ahorro';
type IconName = ComponentProps<typeof Feather>['name'];

type Game = {
  id: string;
  name: string;
  studio: string;
  mark: string;
  tint: string;
  added: boolean;
};

type Preferences = {
  mode: Mode;
  fps: '60' | '90' | '120';
  access: 'Estándar' | 'Shizuku' | 'Root';
  switches: Record<string, boolean>;
};

const STORAGE_GAMES = 'game-turbo:games:v1';
const STORAGE_PREFERENCES = 'game-turbo:preferences:v1';

const initialGames: Game[] = [
  { id: 'free-fire', name: 'Free Fire', studio: 'Garena', mark: 'FF', tint: '#f6cf78', added: true },
  { id: 'clash-royale', name: 'Clash Royale', studio: 'Supercell', mark: 'CR', tint: '#e3b86e', added: true },
  { id: 'minecraft', name: 'Minecraft', studio: 'Mojang', mark: 'M', tint: '#91af78', added: true },
  { id: 'roblox', name: 'Roblox', studio: 'Roblox Corporation', mark: 'R', tint: '#e8ebf0', added: false },
  { id: 'call-of-duty', name: 'Call of Duty', studio: 'Activision', mark: 'COD', tint: '#59656c', added: false },
  { id: 'brawl-stars', name: 'Brawl Stars', studio: 'Supercell', mark: 'BS', tint: '#f1bc58', added: false },
];

const initialPreferences: Preferences = {
  mode: 'Equilibrado',
  fps: '60',
  access: 'Estándar',
  switches: {
    quiet: true,
    touchLock: true,
    fpsCounter: true,
    chargeProtection: true,
    thermalControl: true,
    networkBoost: true,
  },
};

const navItems: { key: Screen; label: string; icon: IconName }[] = [
  { key: 'home', label: 'Inicio', icon: 'home' },
  { key: 'games', label: 'Juegos', icon: 'grid' },
  { key: 'settings', label: 'Ajustes', icon: 'sliders' },
  { key: 'monitor', label: 'Monitor', icon: 'activity' },
];

function GameIcon({ game, size = 50 }: { game: Game; size?: number }) {
  return (
    <View
      style={[
        styles.gameIcon,
        { width: size, height: size, borderRadius: size * 0.3, backgroundColor: game.tint },
      ]}
    >
      <Text style={[styles.gameIconText, { fontSize: size * 0.29 }]}>{game.mark}</Text>
    </View>
  );
}

function SectionHeading({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <View style={styles.sectionHeading}>
      <View style={{ flex: 1 }}>
        <Text style={styles.sectionTitle}>{title}</Text>
        {subtitle ? <Text style={styles.sectionSubtitle}>{subtitle}</Text> : null}
      </View>
      {action}
    </View>
  );
}

function StatCard({
  icon,
  label,
  value,
  note,
  color = '#315f9f',
}: {
  icon: IconName;
  label: string;
  value: string;
  note: string;
  color?: string;
}) {
  return (
    <View style={styles.statCard}>
      <View style={[styles.statIcon, { backgroundColor: `${color}18` }]}>
        <Feather name={icon} size={15} color={color} />
      </View>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statNote}>{note}</Text>
    </View>
  );
}

function SettingSwitch({
  icon,
  title,
  description,
  value,
  onValueChange,
}: {
  icon: IconName;
  title: string;
  description: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}) {
  return (
    <View style={styles.settingRow}>
      <View style={styles.settingIcon}>
        <Feather name={icon} size={15} color="#5578a7" />
      </View>
      <View style={styles.settingCopy}>
        <Text style={styles.settingTitle}>{title}</Text>
        <Text style={styles.settingDescription}>{description}</Text>
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: '#dce1e8', true: '#84a3ce' }}
        thumbColor="#ffffff"
        accessibilityLabel={title}
      />
    </View>
  );
}

function ChoicePill({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.choicePill,
        selected && styles.choicePillSelected,
        pressed && styles.pressed,
      ]}
    >
      <Text style={[styles.choicePillText, selected && styles.choicePillTextSelected]}>
        {label}
      </Text>
    </Pressable>
  );
}

export default function GameTurboScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [screen, setScreen] = useState<Screen>('home');
  const [games, setGames] = useState<Game[]>(initialGames);
  const [preferences, setPreferences] = useState<Preferences>(initialPreferences);
  const [storageReady, setStorageReady] = useState(false);
  const [storageWarning, setStorageWarning] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedGame, setSelectedGame] = useState<Game>(initialGames[0]);
  const [toast, setToast] = useState('');

  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const activeGames = games.filter((game) => game.added);
  const featuredGame = activeGames[0] ?? games[0] ?? initialGames[0];
  const filteredGames = useMemo(
    () => games.filter((game) => game.name.toLocaleLowerCase().includes(search.toLocaleLowerCase())),
    [games, search],
  );

  useEffect(() => {
    let mounted = true;
    const restore = async () => {
      try {
        const [savedGames, savedPreferences] = await Promise.all([
          AsyncStorage.getItem(STORAGE_GAMES),
          AsyncStorage.getItem(STORAGE_PREFERENCES),
        ]);
        if (!mounted) return;
        if (savedGames) setGames(JSON.parse(savedGames) as Game[]);
        if (savedPreferences) {
          const parsed = JSON.parse(savedPreferences) as Partial<Preferences>;
          setPreferences({
            ...initialPreferences,
            ...parsed,
            switches: { ...initialPreferences.switches, ...parsed.switches },
          });
        }
      } catch {
        if (mounted) setStorageWarning(true);
      } finally {
        if (mounted) setStorageReady(true);
      }
    };
    void restore();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!storageReady) return;
    AsyncStorage.multiSet([
      [STORAGE_GAMES, JSON.stringify(games)],
      [STORAGE_PREFERENCES, JSON.stringify(preferences)],
    ]).catch(() => setStorageWarning(true));
  }, [games, preferences, storageReady]);

  const notify = useCallback((message: string) => {
    setToast(message);
    setTimeout(() => setToast(''), 2200);
  }, []);

  const launchGame = useCallback((game: Game) => {
    setSelectedGame(game);
    setScreen('launch');
  }, []);

  const finishLaunch = useCallback(() => {
    setScreen('panel');
  }, []);

  const updateSwitch = (key: string, value: boolean) => {
    setPreferences((current) => ({
      ...current,
      switches: { ...current.switches, [key]: value },
    }));
  };

  const toggleGame = (id: string) => {
    const selected = games.find((game) => game.id === id);
    setGames((current) =>
      current.map((game) => (game.id === id ? { ...game, added: !game.added } : game)),
    );
    if (selected) notify(selected.added ? `${selected.name} eliminado` : `${selected.name} añadido`);
  };

  if (screen === 'launch') {
    return (
      <GameEntry
        gameName={selectedGame.name}
        onCancel={() => setScreen('home')}
        onComplete={finishLaunch}
      />
    );
  }

  if (screen === 'panel') {
    return (
      <GamePanel
        gameName={selectedGame.name}
        mode={preferences.mode}
        fps={preferences.fps}
        quiet={preferences.switches.quiet}
        networkBoost={preferences.switches.networkBoost}
        onModeChange={(mode) => setPreferences((current) => ({ ...current, mode }))}
        onFpsChange={(fps) => setPreferences((current) => ({ ...current, fps }))}
        onQuietChange={(quiet) => updateSwitch('quiet', quiet)}
        onNetworkBoostChange={(networkBoost) => updateSwitch('networkBoost', networkBoost)}
        onClose={() => setScreen('home')}
      />
    );
  }

  const pageTitle =
    screen === 'home' ? 'Game turbo' :
    screen === 'games' ? 'Lista de juegos' :
    screen === 'settings' ? 'Personalización' : 'Monitoreo';

  return (
    <View
      style={[
        styles.root,
        { backgroundColor: colors.background, paddingTop: topInset },
      ]}
    >
      <StatusBar style="dark" />
      <View style={styles.topBar}>
        {screen === 'home' ? (
          <View style={styles.brandMark}>
            <Feather name="zap" size={17} color="#315f9f" />
          </View>
        ) : (
          <Pressable
            accessibilityLabel="Volver al inicio"
            onPress={() => setScreen('home')}
            style={styles.backButton}
          >
            <Feather name="arrow-left" size={19} color="#526174" />
          </Pressable>
        )}
        <View style={styles.topBarTitleWrap}>
          <Text style={styles.topBarTitle}>{pageTitle}</Text>
          <Text style={styles.topBarKicker}>EXPLORAR · GAME TURBO</Text>
        </View>
        <Pressable
          accessibilityLabel="Abrir ajustes"
          onPress={() => setScreen('settings')}
          style={styles.headerAction}
        >
          <Feather name={screen === 'games' ? 'more-horizontal' : 'settings'} size={18} color="#657284" />
        </Pressable>
      </View>

      {storageWarning ? (
        <View style={styles.storageNotice}>
          <Feather name="alert-circle" size={14} color="#9a6d22" />
          <Text style={styles.storageNoticeText}>No se pudieron restaurar algunos ajustes guardados.</Text>
          <Pressable onPress={() => setStorageWarning(false)}><Feather name="x" size={14} color="#9a6d22" /></Pressable>
        </View>
      ) : null}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {screen === 'home' ? (
          <>
            <View style={styles.welcomeRow}>
              <View>
                <Text style={styles.eyebrow}>LISTA PARA TU PRÓXIMA PARTIDA</Text>
                <Text style={styles.welcomeTitle}>Juega a tu ritmo.</Text>
              </View>
              <View style={styles.readyBadge}>
                <View style={styles.readyDot} />
                <Text style={styles.readyText}>Listo</Text>
              </View>
            </View>

            <View style={styles.featureCard}>
              <View style={styles.featureTop}>
                <View style={styles.featureGame}>
                  <GameIcon game={featuredGame} size={52} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.featureEyebrow}>PERFIL ACTIVO</Text>
                    <Text style={styles.featureGameName}>{featuredGame?.name ?? 'Añade un juego'}</Text>
                    <Text style={styles.featureDetail}>Preparado para jugar</Text>
                  </View>
                  <View style={styles.featureGlyph}>
                    <Feather name="zap" size={24} color="#ffffff" />
                  </View>
                </View>
                <View style={styles.featureDivider} />
                <View style={styles.featureActions}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.featureTitle}>Panel de juego</Text>
                    <Text style={styles.featureDescription}>Abre la animación de entrada y los controles.</Text>
                  </View>
                  <Pressable
                    accessibilityRole="button"
                    testID="launch-game"
                    onPress={() => featuredGame && launchGame(featuredGame)}
                    style={({ pressed }) => [styles.playButton, pressed && styles.pressed]}
                  >
                    <Feather name="play" size={17} color="#ffffff" />
                    <Text style={styles.playButtonText}>Jugar</Text>
                  </Pressable>
                </View>
              </View>
            </View>

            <SectionHeading
              title="Estado del dispositivo"
              subtitle="Lecturas de demostración"
              action={<Text style={styles.demoPill}>SIMULADO</Text>}
            />
            <View style={styles.statsRow}>
              <StatCard icon="activity" label="FPS" value={`${preferences.fps}`} note="objetivo" />
              <StatCard icon="cpu" label="CPU" value="48%" note="uso simulado" color="#5e8a72" />
              <StatCard icon="thermometer" label="Temp." value="38°" note="estimada" color="#c28a55" />
            </View>

            <SectionHeading
              title="Tus juegos"
              subtitle={`${activeGames.length} juegos añadidos`}
              action={
                <Pressable onPress={() => setScreen('games')} style={styles.textAction}>
                  <Text style={styles.textActionLabel}>Ver todo</Text>
                  <Feather name="chevron-right" size={15} color="#315f9f" />
                </Pressable>
              }
            />
            <View style={styles.listCard}>
              {activeGames.slice(0, 3).map((game, index) => (
                <View key={game.id} style={[styles.gameRow, index === 0 && styles.firstGameRow]}>
                  <GameIcon game={game} size={42} />
                  <View style={styles.gameCopy}>
                    <Text style={styles.gameName}>{game.name}</Text>
                    <Text style={styles.gameStudio}>{game.studio} · Perfil {preferences.mode.toLowerCase()}</Text>
                  </View>
                  <Pressable
                    accessibilityLabel={`Entrar a ${game.name}`}
                    onPress={() => launchGame(game)}
                    style={({ pressed }) => [styles.miniPlay, pressed && styles.pressed]}
                  >
                    <Feather name="play" size={15} color="#315f9f" />
                  </Pressable>
                </View>
              ))}
              {activeGames.length === 0 ? (
                <View style={styles.emptyState}>
                  <Feather name="grid" size={22} color="#8192a8" />
                  <Text style={styles.emptyTitle}>Aún no hay juegos añadidos</Text>
                  <Text style={styles.emptyDescription}>Abre la lista para elegir tus juegos.</Text>
                </View>
              ) : null}
            </View>
          </>
        ) : null}

        {screen === 'games' ? (
          <>
            <SectionHeading title="Biblioteca" subtitle="Elige qué juegos aparecen en Game turbo." />
            <View style={styles.searchBox}>
              <Feather name="search" size={16} color="#8a96a5" />
              <TextInput
                value={search}
                onChangeText={setSearch}
                placeholder="Buscar juegos"
                placeholderTextColor="#9ba5b2"
                style={styles.searchInput}
                accessibilityLabel="Buscar juegos"
              />
              {search.length > 0 ? (
                <Pressable accessibilityLabel="Limpiar búsqueda" onPress={() => setSearch('')}>
                  <Feather name="x" size={15} color="#77808e" />
                </Pressable>
              ) : null}
            </View>
            <View style={styles.addGamesNotice}>
              <View style={styles.noticeIcon}><Feather name="info" size={15} color="#456fa8" /></View>
              <Text style={styles.addGamesNoticeText}>Añade un juego para elegir su perfil y entrar al panel.</Text>
            </View>
            <View style={styles.listCard}>
              {filteredGames.map((game, index) => (
                <View key={game.id} style={[styles.gameRow, index === 0 && styles.firstGameRow]}>
                  <GameIcon game={game} size={42} />
                  <View style={styles.gameCopy}>
                    <Text style={styles.gameName}>{game.name}</Text>
                    <Text style={styles.gameStudio}>{game.studio}</Text>
                  </View>
                  {game.added ? (
                    <>
                      <Pressable onPress={() => launchGame(game)} style={styles.miniPlay}>
                        <Feather name="play" size={15} color="#315f9f" />
                      </Pressable>
                      <Pressable onPress={() => toggleGame(game.id)} style={styles.addedButton}>
                        <Feather name="check" size={13} color="#5276a5" />
                        <Text style={styles.addedButtonText}>Añadido</Text>
                      </Pressable>
                    </>
                  ) : (
                    <Pressable onPress={() => toggleGame(game.id)} style={styles.addButton}>
                      <Feather name="plus" size={15} color="#315f9f" />
                      <Text style={styles.addButtonText}>Añadir</Text>
                    </Pressable>
                  )}
                </View>
              ))}
              {filteredGames.length === 0 ? (
                <View style={styles.emptyState}>
                  <Feather name="search" size={22} color="#8192a8" />
                  <Text style={styles.emptyTitle}>No encontramos ese juego</Text>
                  <Text style={styles.emptyDescription}>Prueba con otro nombre.</Text>
                </View>
              ) : null}
            </View>
          </>
        ) : null}

        {screen === 'settings' ? (
          <>
            <SectionHeading title="Rendimiento" subtitle="Ajusta el perfil para cada sesión." />
            <View style={styles.card}>
              <Text style={styles.cardLabel}>PERFIL DE JUEGO</Text>
              <View style={styles.choiceRow}>
                {(['Equilibrado', 'Rendimiento', 'Ahorro'] as Mode[]).map((mode) => (
                  <ChoicePill
                    key={mode}
                    label={mode}
                    selected={preferences.mode === mode}
                    onPress={() => setPreferences((current) => ({ ...current, mode }))}
                  />
                ))}
              </View>
              <View style={styles.cardDivider} />
              <Text style={styles.cardLabel}>FRECUENCIA DE CUADROS</Text>
              <View style={styles.choiceRow}>
                {(['60', '90', '120'] as const).map((fps) => (
                  <ChoicePill
                    key={fps}
                    label={`${fps} FPS`}
                    selected={preferences.fps === fps}
                    onPress={() => setPreferences((current) => ({ ...current, fps }))}
                  />
                ))}
              </View>
              <Text style={styles.helperText}>Valor visual de demostración; no cambia la tasa real del teléfono.</Text>
            </View>

            <SectionHeading title="Acceso del sistema" subtitle="Preferencias de muestra" />
            <View style={styles.card}>
              <View style={styles.accessHeading}>
                <View style={styles.settingIcon}><Feather name="shield" size={16} color="#5578a7" /></View>
                <View style={styles.gameCopy}>
                  <Text style={styles.settingTitle}>Modo de acceso</Text>
                  <Text style={styles.settingDescription}>Elige el modo que aparece en el panel.</Text>
                </View>
              </View>
              <View style={styles.choiceRow}>
                {(['Estándar', 'Shizuku', 'Root'] as const).map((access) => (
                  <ChoicePill
                    key={access}
                    label={access}
                    selected={preferences.access === access}
                    onPress={() => setPreferences((current) => ({ ...current, access }))}
                  />
                ))}
              </View>
            </View>

            <SectionHeading title="Controles rápidos" />
            <View style={styles.card}>
              <SettingSwitch
                icon="bell-off"
                title="No molestar"
                description="Silencia avisos durante la partida."
                value={preferences.switches.quiet}
                onValueChange={(value) => updateSwitch('quiet', value)}
              />
              <SettingSwitch
                icon="lock"
                title="Bloqueo táctil"
                description="Evita toques accidentales."
                value={preferences.switches.touchLock}
                onValueChange={(value) => updateSwitch('touchLock', value)}
              />
              <SettingSwitch
                icon="activity"
                title="Contador de FPS"
                description="Muestra el valor simulado en el panel."
                value={preferences.switches.fpsCounter}
                onValueChange={(value) => updateSwitch('fpsCounter', value)}
              />
              <SettingSwitch
                icon="battery-charging"
                title="Protección de carga"
                description="Preferencia visual de temperatura y carga."
                value={preferences.switches.chargeProtection}
                onValueChange={(value) => updateSwitch('chargeProtection', value)}
              />
              <SettingSwitch
                icon="thermometer"
                title="Control térmico"
                description="Activa avisos de temperatura simulados."
                value={preferences.switches.thermalControl}
                onValueChange={(value) => updateSwitch('thermalControl', value)}
              />
              <SettingSwitch
                icon="wifi"
                title="Prioridad de red"
                description="Muestra el acceso rápido de Wi‑Fi en el panel."
                value={preferences.switches.networkBoost}
                onValueChange={(value) => updateSwitch('networkBoost', value)}
              />
            </View>
            <View style={styles.disclaimerCard}>
              <Feather name="info" size={16} color="#5278aa" />
              <Text style={styles.disclaimerText}>Esta app reproduce la interfaz. No activa permisos Root/Shizuku ni modifica CPU, GPU o red.</Text>
            </View>
          </>
        ) : null}

        {screen === 'monitor' ? (
          <>
            <SectionHeading title="Monitoreo" subtitle="Lecturas visuales para la sesión actual." />
            <View style={styles.statsRow}>
              <StatCard icon="activity" label="FPS" value={preferences.fps} note="objetivo" />
              <StatCard icon="cpu" label="CPU" value="48%" note="simulado" color="#5e8a72" />
              <StatCard icon="zap" label="GPU" value="62%" note="simulado" color="#bb7092" />
            </View>
            <View style={styles.card}>
              <View style={styles.monitorHeading}>
                <View>
                  <Text style={styles.cardTitle}>Rendimiento del dispositivo</Text>
                  <Text style={styles.cardSubtitle}>Datos ilustrativos de la maqueta</Text>
                </View>
                <View style={styles.liveDot} />
              </View>
              <Meter label="Procesador" value={48} color="#4c78b2" />
              <Meter label="Gráficos" value={62} color="#8a70b8" />
              <Meter label="Memoria" value={41} color="#5e8a72" />
              <View style={styles.monitorFooter}>
                <Feather name="thermometer" size={14} color="#c28651" />
                <Text style={styles.monitorFooterText}>Temperatura estimada</Text>
                <Text style={styles.monitorFooterValue}>38 °C</Text>
              </View>
            </View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Procesos recientes</Text>
              <Text style={styles.cardSubtitle}>Resumen de demostración</Text>
              {[
                ['Game turbo', 'En primer plano', '48%'],
                [featuredGame?.name ?? 'Sin juego', 'Perfil activo', '32%'],
                ['Sistema', 'Servicios del dispositivo', '20%'],
              ].map(([name, detail, value]) => (
                <View key={name} style={styles.processRow}>
                  <View style={styles.processDot} />
                  <View style={styles.gameCopy}><Text style={styles.gameName}>{name}</Text><Text style={styles.gameStudio}>{detail}</Text></View>
                  <Text style={styles.processValue}>{value}</Text>
                </View>
              ))}
            </View>
          </>
        ) : null}
      </ScrollView>

      <View style={[styles.bottomNav, { paddingBottom: Math.max(bottomInset, 7) }]}>
        {navItems.map((item) => {
          const active = screen === item.key;
          return (
            <Pressable
              key={item.key}
              accessibilityRole="tab"
              accessibilityState={{ selected: active }}
              onPress={() => {
                setScreen(item.key);
                setSearch('');
              }}
              style={({ pressed }) => [styles.navItem, pressed && styles.pressed]}
            >
              <View style={[styles.navIconWrap, active && styles.navIconWrapActive]}>
                <Feather name={item.icon} size={18} color={active ? '#315f9f' : '#8490a0'} />
              </View>
              <Text style={[styles.navLabel, active && styles.navLabelActive]}>{item.label}</Text>
            </Pressable>
          );
        })}
      </View>

      {toast ? (
        <View style={styles.toast}>
          <Feather name="check-circle" size={15} color="#ffffff" />
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      ) : null}
    </View>
  );
}

function Meter({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <View style={styles.meter}>
      <View style={styles.meterLabelRow}>
        <Text style={styles.meterLabel}>{label}</Text>
        <Text style={styles.meterValue}>{value}%</Text>
      </View>
      <View style={styles.meterTrack}><View style={[styles.meterFill, { width: `${value}%`, backgroundColor: color }]} /></View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  topBar: { minHeight: 58, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 19, gap: 12 },
  brandMark: { width: 35, height: 35, borderRadius: 12, backgroundColor: '#e5eefc', alignItems: 'center', justifyContent: 'center' },
  backButton: { width: 35, height: 35, borderRadius: 12, backgroundColor: '#eef2f7', alignItems: 'center', justifyContent: 'center' },
  topBarTitleWrap: { flex: 1 },
  topBarTitle: { color: '#27303e', fontSize: 17, fontWeight: '700', letterSpacing: -0.3 },
  topBarKicker: { color: '#8d97a5', fontSize: 8, letterSpacing: 1.15, marginTop: 3, fontWeight: '700' },
  headerAction: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 20, gap: 14 },
  welcomeRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 2, paddingTop: 4, paddingBottom: 2 },
  eyebrow: { fontSize: 8, color: '#8b96a5', letterSpacing: 1.1, fontWeight: '700', marginBottom: 5 },
  welcomeTitle: { fontSize: 22, lineHeight: 27, fontWeight: '700', color: '#273343', letterSpacing: -0.5 },
  readyBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 20, backgroundColor: '#e9f3ee' },
  readyDot: { width: 6, height: 6, borderRadius: 5, backgroundColor: '#5a9970' },
  readyText: { color: '#4f8060', fontWeight: '700', fontSize: 9 },
  featureCard: { backgroundColor: '#eaf1fb', borderRadius: 20, padding: 14, borderWidth: 1, borderColor: '#dce7f5' },
  featureTop: { gap: 11 },
  featureGame: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  featureEyebrow: { color: '#788ca8', fontSize: 8, fontWeight: '700', letterSpacing: 0.9, marginBottom: 4 },
  featureGameName: { fontSize: 15, color: '#27374c', fontWeight: '700' },
  featureDetail: { fontSize: 9, color: '#7f8da1', marginTop: 3 },
  featureGlyph: { width: 42, height: 42, borderRadius: 15, backgroundColor: '#416ea8', alignItems: 'center', justifyContent: 'center' },
  featureDivider: { height: 1, backgroundColor: '#d5e0ef' },
  featureActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  featureTitle: { color: '#2c3a4d', fontSize: 12, fontWeight: '700' },
  featureDescription: { color: '#7d8998', fontSize: 9, lineHeight: 13, marginTop: 3 },
  playButton: { minWidth: 80, height: 39, borderRadius: 12, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: '#315f9f' },
  playButtonText: { color: '#ffffff', fontSize: 11, fontWeight: '700' },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', minHeight: 30, gap: 8, marginTop: 2 },
  sectionTitle: { color: '#313c4c', fontSize: 13, fontWeight: '700' },
  sectionSubtitle: { color: '#8a95a3', fontSize: 9, marginTop: 3 },
  demoPill: { color: '#8491a2', fontSize: 7, letterSpacing: 0.8, fontWeight: '800', backgroundColor: '#edf0f4', paddingHorizontal: 7, paddingVertical: 5, borderRadius: 10 },
  statsRow: { flexDirection: 'row', gap: 8 },
  statCard: { flex: 1, minHeight: 97, padding: 10, backgroundColor: '#ffffff', borderRadius: 15, borderWidth: 1, borderColor: '#e8ebf1' },
  statIcon: { width: 25, height: 25, borderRadius: 8, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  statLabel: { color: '#8a95a3', fontSize: 8, fontWeight: '600' },
  statValue: { color: '#303c4d', fontSize: 17, fontWeight: '700', marginTop: 2 },
  statNote: { color: '#9aa3af', fontSize: 7, marginTop: 1 },
  textAction: { flexDirection: 'row', alignItems: 'center', gap: 1 },
  textActionLabel: { color: '#315f9f', fontSize: 9, fontWeight: '700' },
  listCard: { backgroundColor: '#ffffff', borderRadius: 16, borderWidth: 1, borderColor: '#e8ebf1', overflow: 'hidden' },
  gameRow: { minHeight: 65, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 11, gap: 10, borderTopWidth: 1, borderTopColor: '#f0f2f5' },
  firstGameRow: { borderTopWidth: 0 },
  gameIcon: { alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(30,48,72,0.08)' },
  gameIconText: { color: '#344155', fontWeight: '800' },
  gameCopy: { flex: 1, minWidth: 0 },
  gameName: { color: '#344052', fontSize: 11, fontWeight: '700' },
  gameStudio: { color: '#8994a2', fontSize: 8, marginTop: 3 },
  miniPlay: { width: 31, height: 31, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: '#edf3fc' },
  emptyState: { alignItems: 'center', padding: 24, gap: 8 },
  emptyTitle: { color: '#3f4c5e', fontSize: 11, fontWeight: '700' },
  emptyDescription: { color: '#8a95a3', fontSize: 9, textAlign: 'center' },
  searchBox: { height: 42, borderRadius: 13, backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#e7ebf1', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 11, gap: 8 },
  searchInput: { flex: 1, paddingVertical: 0, color: '#303b4a', fontSize: 11 },
  addGamesNotice: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 13, backgroundColor: '#edf3fc' },
  noticeIcon: { width: 27, height: 27, borderRadius: 9, backgroundColor: '#dfeafb', alignItems: 'center', justifyContent: 'center' },
  addGamesNoticeText: { flex: 1, color: '#6f7e91', fontSize: 9, lineHeight: 13 },
  addButton: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: 9, paddingHorizontal: 9, paddingVertical: 7, backgroundColor: '#eaf1fb' },
  addButtonText: { color: '#315f9f', fontSize: 9, fontWeight: '700' },
  addedButton: { flexDirection: 'row', alignItems: 'center', gap: 3, borderRadius: 9, paddingHorizontal: 7, paddingVertical: 7, backgroundColor: '#f1f4f8' },
  addedButtonText: { color: '#7f8997', fontSize: 8, fontWeight: '600' },
  card: { backgroundColor: '#ffffff', borderRadius: 16, borderWidth: 1, borderColor: '#e8ebf1', paddingHorizontal: 13, paddingVertical: 12, gap: 10 },
  cardLabel: { color: '#8792a1', fontSize: 8, fontWeight: '800', letterSpacing: 0.85 },
  cardTitle: { color: '#354154', fontSize: 12, fontWeight: '700' },
  cardSubtitle: { color: '#8b95a2', fontSize: 8, marginTop: 3 },
  cardDivider: { height: 1, backgroundColor: '#eff1f5', marginVertical: 2 },
  choiceRow: { flexDirection: 'row', gap: 5 },
  choicePill: { flex: 1, minHeight: 32, paddingHorizontal: 4, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: '#f1f3f7', borderWidth: 1, borderColor: 'transparent' },
  choicePillSelected: { backgroundColor: '#edf4ff', borderColor: '#b8cae2' },
  choicePillText: { color: '#7c8796', fontSize: 8, fontWeight: '600', textAlign: 'center' },
  choicePillTextSelected: { color: '#315f9f', fontWeight: '800' },
  helperText: { color: '#9aa3af', fontSize: 8, lineHeight: 12 },
  accessHeading: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 2 },
  settingRow: { minHeight: 57, flexDirection: 'row', alignItems: 'center', gap: 9, borderTopWidth: 1, borderTopColor: '#f0f2f5' },
  settingIcon: { width: 29, height: 29, borderRadius: 9, backgroundColor: '#eff4fb', alignItems: 'center', justifyContent: 'center' },
  settingCopy: { flex: 1 },
  settingTitle: { color: '#3c4858', fontSize: 10, fontWeight: '700' },
  settingDescription: { color: '#8994a2', fontSize: 8, lineHeight: 12, marginTop: 3 },
  disclaimerCard: { flexDirection: 'row', gap: 9, padding: 11, borderRadius: 13, backgroundColor: '#edf3fc', alignItems: 'flex-start' },
  disclaimerText: { flex: 1, color: '#6f7e91', fontSize: 8, lineHeight: 13 },
  monitorHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#67a27a' },
  meter: { marginTop: 7 },
  meterLabelRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 },
  meterLabel: { color: '#748091', fontSize: 9 },
  meterValue: { color: '#465568', fontSize: 9, fontWeight: '700' },
  meterTrack: { height: 5, borderRadius: 5, backgroundColor: '#edf0f4', overflow: 'hidden' },
  meterFill: { height: '100%', borderRadius: 5 },
  monitorFooter: { marginTop: 11, borderTopWidth: 1, borderTopColor: '#eff1f5', paddingTop: 10, flexDirection: 'row', alignItems: 'center', gap: 6 },
  monitorFooterText: { color: '#808c9b', fontSize: 9, flex: 1 },
  monitorFooterValue: { color: '#49576a', fontSize: 10, fontWeight: '700' },
  processRow: { flexDirection: 'row', alignItems: 'center', gap: 9, minHeight: 49, borderTopWidth: 1, borderTopColor: '#f0f2f5' },
  processDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#7898c4' },
  processValue: { color: '#647387', fontSize: 10, fontWeight: '700' },
  bottomNav: { minHeight: 65, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', marginHorizontal: 12, marginTop: 4, paddingTop: 4, borderTopLeftRadius: 17, borderTopRightRadius: 17, backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#e8ebf1', shadowColor: '#29466e', shadowOpacity: 0.08, shadowRadius: 11, shadowOffset: { width: 0, height: -2 }, elevation: 5 },
  navItem: { minWidth: 59, alignItems: 'center', justifyContent: 'center', gap: 2 },
  navIconWrap: { width: 34, height: 26, alignItems: 'center', justifyContent: 'center', borderRadius: 12 },
  navIconWrapActive: { backgroundColor: '#e6effc' },
  navLabel: { color: '#8691a0', fontSize: 8, fontWeight: '600' },
  navLabelActive: { color: '#315f9f', fontWeight: '800' },
  storageNotice: { marginHorizontal: 16, marginBottom: 5, paddingHorizontal: 10, paddingVertical: 8, backgroundColor: '#fff6e3', borderRadius: 10, flexDirection: 'row', alignItems: 'center', gap: 7 },
  storageNoticeText: { flex: 1, color: '#806a43', fontSize: 8 },
  toast: { position: 'absolute', bottom: 85, left: 24, right: 24, minHeight: 42, borderRadius: 13, paddingHorizontal: 14, backgroundColor: '#26364b', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, elevation: 7 },
  toastText: { color: '#ffffff', fontSize: 10, fontWeight: '600' },
  pressed: { opacity: 0.74 },
});
