# Game turbo

Recreación móvil en español del flujo de entrada a un juego y su Game Panel. El proyecto usa Expo y funciona como una demo visual e interactiva.

## Ejecutar

1. Instala Node.js y Expo Go en tu teléfono.
2. En esta carpeta ejecuta `npm install`.
3. Ejecuta `npx expo start`.
4. Escanea el código QR con Expo Go.

También puedes ejecutar `npm run android` con un emulador Android configurado.

## Subir a GitHub

Crea un repositorio vacío y sube el contenido de esta carpeta, o usa GitHub Desktop para publicar la carpeta como repositorio.

## Importante

Este ZIP contiene código fuente, no un APK. Los datos de FPS, CPU, GPU y temperatura son ilustrativos; la demo no inicia Free Fire ni cambia el rendimiento real, el Wi‑Fi o los permisos del teléfono.
