import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef, useState } from 'react';
import {
  Animated,
  Easing,
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type Props = {
  gameName: string;
  onComplete: () => void;
  onCancel: () => void;
};

export function GameEntry({ gameName, onComplete, onCancel }: Props) {
  const insets = useSafeAreaInsets();
  const rotation = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0.86)).current;
  const reveal = useRef(new Animated.Value(0)).current;
  const [phase, setPhase] = useState('Activando el núcleo de energía');

  useEffect(() => {
    const spinLoop = Animated.loop(
      Animated.timing(rotation, {
        toValue: 1,
        duration: 3600,
        easing: Easing.linear,
        useNativeDriver: true,
      }),
    );
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.08, duration: 650, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0.86, duration: 650, easing: Easing.inOut(Easing.cubic), useNativeDriver: true }),
      ]),
    );
    Animated.timing(reveal, { toValue: 1, duration: 420, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    spinLoop.start();
    pulseLoop.start();
    const phaseTimer = setTimeout(() => setPhase(`Preparando ${gameName}`), 1000);
    const finishTimer = setTimeout(onComplete, 3100);
    return () => {
      clearTimeout(phaseTimer);
      clearTimeout(finishTimer);
      spinLoop.stop();
      pulseLoop.stop();
    };
  }, [gameName, onComplete, pulse, reveal, rotation]);

  const spin = rotation.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const fade = reveal;
  const scale = reveal.interpolate({ inputRange: [0, 1], outputRange: [0.84, 1] });
  const progressWidth = reveal.interpolate({ inputRange: [0, 1], outputRange: ['8%', '78%'] });

  return (
    <View style={[styles.root, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      <StatusBar style="light" />
      <View style={styles.glowOuter} />
      <View style={styles.glowInner} />
      <View style={styles.topRow}>
        <Pressable accessibilityLabel="Cancelar entrada al juego" onPress={onCancel} style={styles.closeButton}>
          <Feather name="x" size={18} color="#dbe7f6" />
        </Pressable>
        <Text style={styles.topLabel}>GAME TURBO · INICIO DE PARTIDA</Text>
        <View style={{ width: 36 }} />
      </View>

      <View style={styles.content}>
        <Animated.View style={{ opacity: fade, transform: [{ scale }] }}>
          <View style={styles.cubeStage}>
            <Animated.View style={[styles.orbit, { transform: [{ rotate: spin }] }]}>
              <View style={styles.orbitDot} />
            </Animated.View>
            <Animated.View style={[styles.orbitSecondary, { transform: [{ rotate: spin }] }]}>
              <View style={styles.orbitSecondaryDot} />
            </Animated.View>
            <Animated.View style={[styles.cubeGlow, { transform: [{ scale: pulse }] }]} />
            <Animated.View style={[styles.iconFrame, { transform: [{ scale: pulse }] }]}>
              <Image source={require('../assets/images/icon.png')} style={styles.cubeImage} />
            </Animated.View>
            <View style={styles.energyLine} />
          </View>
          <Text style={styles.eyebrow}>NÚCLEO DE ENERGÍA</Text>
          <Text style={styles.gameTitle}>{gameName}</Text>
          <Text style={styles.phaseText}>{phase}</Text>
        </Animated.View>

        <View style={styles.loadingWrap}>
          <View style={styles.loadingTrack}>
            <Animated.View style={[styles.loadingFill, { width: progressWidth }]} />
          </View>
          <View style={styles.loadingLabels}>
            <Text style={styles.loadingCaption}>Optimizando la sesión</Text>
            <Text style={styles.loadingPercent}>78%</Text>
          </View>
        </View>
      </View>

      <View style={styles.footer}>
        <View style={styles.footerLine} />
        <Text style={styles.footerTitle}>GAME TURBO</Text>
        <Text style={styles.footerCopy}>Preparando el panel de juego</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#070b13', justifyContent: 'space-between', overflow: 'hidden' },
  glowOuter: { position: 'absolute', width: 370, height: 370, borderRadius: 190, backgroundColor: '#192949', opacity: 0.48, top: '26%', alignSelf: 'center' },
  glowInner: { position: 'absolute', width: 230, height: 230, borderRadius: 120, backgroundColor: '#254b72', opacity: 0.28, top: '34%', alignSelf: 'center' },
  topRow: { height: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 17 },
  closeButton: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  topLabel: { color: '#8496ae', fontSize: 8, fontWeight: '800', letterSpacing: 1.2 },
  content: { alignItems: 'center', justifyContent: 'center', flex: 1, paddingHorizontal: 24 },
  cubeStage: { width: 220, height: 220, alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: 9 },
  orbit: { position: 'absolute', width: 198, height: 198, borderRadius: 120, borderWidth: 1, borderColor: 'rgba(106,197,255,0.42)', transform: [{ rotate: '-18deg' }] },
  orbitDot: { position: 'absolute', width: 9, height: 9, borderRadius: 6, backgroundColor: '#9ce8ff', top: 27, right: 25, shadowColor: '#65cfff', shadowOpacity: 0.9, shadowRadius: 10, elevation: 6 },
  orbitSecondary: { position: 'absolute', width: 158, height: 158, borderRadius: 100, borderWidth: 1, borderColor: 'rgba(73,147,223,0.36)', transform: [{ rotate: '50deg' }] },
  orbitSecondaryDot: { position: 'absolute', width: 6, height: 6, borderRadius: 4, backgroundColor: '#5eb7f4', bottom: 20, left: 23 },
  cubeGlow: { position: 'absolute', width: 116, height: 116, borderRadius: 34, backgroundColor: '#1c5e9b', opacity: 0.43, shadowColor: '#3dcbff', shadowOpacity: 0.85, shadowRadius: 30, elevation: 10 },
  iconFrame: { width: 102, height: 102, borderRadius: 29, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(174,232,255,0.55)' },
  cubeImage: { width: '100%', height: '100%' },
  energyLine: { position: 'absolute', width: 210, height: 1, backgroundColor: 'rgba(116,199,255,0.25)', bottom: 13 },
  eyebrow: { color: '#83dfff', textAlign: 'center', fontSize: 8, letterSpacing: 2, fontWeight: '800', marginTop: 3 },
  gameTitle: { color: '#ffffff', fontSize: 24, fontWeight: '800', textAlign: 'center', marginTop: 9, letterSpacing: -0.4 },
  phaseText: { color: '#9caec1', fontSize: 11, textAlign: 'center', marginTop: 7 },
  loadingWrap: { width: '100%', maxWidth: 310, marginTop: 42 },
  loadingTrack: { height: 3, borderRadius: 4, backgroundColor: '#202b3a', overflow: 'hidden' },
  loadingFill: { height: '100%', backgroundColor: '#61cbf4', borderRadius: 4 },
  loadingLabels: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 9 },
  loadingCaption: { color: '#8091a7', fontSize: 8 },
  loadingPercent: { color: '#a9dff3', fontSize: 8, fontWeight: '700' },
  footer: { alignItems: 'center', paddingBottom: 16 },
  footerLine: { width: 28, height: 2, borderRadius: 4, backgroundColor: '#4da9d1', marginBottom: 10 },
  footerTitle: { color: '#7e8fa6', fontSize: 7, fontWeight: '800', letterSpacing: 2 },
  footerCopy: { color: '#596a7f', fontSize: 8, marginTop: 4 },
});
