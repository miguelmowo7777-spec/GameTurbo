import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef, useState, type ComponentProps } from 'react';
import {
  Animated,
  ImageBackground,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type Mode = 'Equilibrado' | 'Rendimiento' | 'Ahorro';
type IconName = ComponentProps<typeof Feather>['name'];

type Props = {
  gameName: string;
  mode: Mode;
  fps: '60' | '90' | '120';
  quiet: boolean;
  networkBoost: boolean;
  onModeChange: (mode: Mode) => void;
  onFpsChange: (fps: '60' | '90' | '120') => void;
  onQuietChange: (value: boolean) => void;
  onNetworkBoostChange: (value: boolean) => void;
  onClose: () => void;
};

function HudButton({
  icon,
  label,
  value,
  selected,
  onPress,
}: {
  icon: IconName;
  label: string;
  value?: string;
  selected: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.hudButton, selected && styles.hudButtonSelected, pressed && styles.pressed]}
    >
      <Feather name={icon} size={13} color={selected ? '#bffbff' : '#d4dde7'} />
      <Text style={styles.hudButtonLabel}>{label}</Text>
      {value ? <Text style={styles.hudButtonValue}>{value}</Text> : null}
    </Pressable>
  );
}

export function GamePanel({
  gameName,
  mode,
  fps,
  quiet,
  networkBoost,
  onModeChange,
  onFpsChange,
  onQuietChange,
  onNetworkBoostChange,
  onClose,
}: Props) {
  const insets = useSafeAreaInsets();
  const leftIn = useRef(new Animated.Value(-26)).current;
  const rightIn = useRef(new Animated.Value(26)).current;
  const [toast, setToast] = useState('');
  const [activeAction, setActiveAction] = useState('FPS');
  const isPerformance = mode === 'Rendimiento';

  useEffect(() => {
    Animated.parallel([
      Animated.spring(leftIn, { toValue: 0, damping: 17, stiffness: 150, useNativeDriver: true }),
      Animated.spring(rightIn, { toValue: 0, damping: 17, stiffness: 150, useNativeDriver: true }),
    ]).start();
  }, [leftIn, rightIn]);

  const notify = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(''), 1800);
  };

  const cycleFps = () => {
    const next = fps === '60' ? '90' : fps === '90' ? '120' : '60';
    onFpsChange(next);
    setActiveAction('FPS');
  };

  const accent = isPerformance ? '#ff557f' : '#6de7d0';
  const modes: Mode[] = ['Equilibrado', 'Rendimiento', 'Ahorro'];

  return (
    <View style={[styles.root, { paddingTop: insets.top, paddingBottom: Math.max(insets.bottom, 10) }]}>
      <StatusBar style="light" />
      <View style={styles.topBar}>
        <Pressable accessibilityLabel="Cerrar panel" onPress={onClose} style={styles.topIcon}>
          <Feather name="arrow-left" size={18} color="#d8e0eb" />
        </Pressable>
        <View style={styles.topCopy}>
          <Text style={styles.topKicker}>GAME TURBO · PANEL DE JUEGO</Text>
          <Text style={styles.topTitle}>{gameName}</Text>
        </View>
        <View style={styles.liveBadge}><View style={[styles.liveDot, { backgroundColor: accent }]} /><Text style={styles.liveText}>EN SESIÓN</Text></View>
      </View>

      <View style={styles.canvasWrap}>
        <ImageBackground
          source={require('../assets/images/gameplay-background.jpg')}
          resizeMode="cover"
          style={styles.gameBackground}
          imageStyle={styles.gameImage}
        >
          <View style={styles.imageShade} />
          <View style={[styles.topHud, { borderColor: `${accent}66` }]}>
            <View style={styles.miniBrand}><Feather name="zap" size={10} color={accent} /><Text style={styles.miniBrandText}>GAME TURBO</Text></View>
            <Text style={styles.hudGameName}>{gameName.toUpperCase()}</Text>
            <Text style={styles.hudStatus}>120 HZ</Text>
          </View>

          <Animated.View style={[styles.sidePanel, styles.leftPanel, { transform: [{ translateX: leftIn }] }]}>
            <HudButton icon="activity" label="FPS" value={fps} selected={activeAction === 'FPS'} onPress={cycleFps} />
            <HudButton icon="cpu" label="CPU" value="48%" selected={activeAction === 'CPU'} onPress={() => { setActiveAction('CPU'); notify('Lectura de CPU simulada'); }} />
            <HudButton icon="sliders" label="TACTO" selected={activeAction === 'TACTO'} onPress={() => { setActiveAction('TACTO'); notify('Sensibilidad lista para ajustar'); }} />
            <HudButton icon="wifi" label="RED" selected={networkBoost} onPress={() => { onNetworkBoostChange(!networkBoost); setActiveAction('RED'); }} />
          </Animated.View>

          <Animated.View style={[styles.sidePanel, styles.rightPanel, { transform: [{ translateX: rightIn }] }]}>
            <HudButton icon="bell-off" label="SILENCIO" selected={quiet} onPress={() => { onQuietChange(!quiet); setActiveAction('SILENCIO'); }} />
            <HudButton icon="shield" label="TOQUES" selected={activeAction === 'TOQUES'} onPress={() => { setActiveAction('TOQUES'); notify('Bloqueo táctil activado en la vista'); }} />
            <HudButton icon="battery-charging" label="CARGA" selected={activeAction === 'CARGA'} onPress={() => { setActiveAction('CARGA'); notify('Protección de carga simulada'); }} />
            <HudButton icon="more-horizontal" label="MÁS" selected={activeAction === 'MÁS'} onPress={() => { setActiveAction('MÁS'); notify('Más controles disponibles'); }} />
          </Animated.View>

          <View style={styles.centerReadout}>
            <View style={[styles.centerRing, { borderColor: accent }]}>
              <Text style={[styles.fpsNumber, { color: accent }]}>{fps}</Text>
              <Text style={styles.fpsUnit}>FPS</Text>
            </View>
            <Text style={styles.modeCaption}>{mode.toUpperCase()}</Text>
          </View>

          <View style={styles.canvasBottom}>
            <View style={styles.miniStat}><Feather name="thermometer" size={10} color="#d6e1ea" /><Text style={styles.miniStatText}>38 °C</Text></View>
            <View style={styles.miniStat}><Feather name="activity" size={10} color="#d6e1ea" /><Text style={styles.miniStatText}>CPU 48%</Text></View>
            <View style={styles.miniStat}><Feather name="wifi" size={10} color="#d6e1ea" /><Text style={styles.miniStatText}>{networkBoost ? 'RED ACTIVA' : 'RED NORMAL'}</Text></View>
          </View>
        </ImageBackground>
      </View>

      <View style={styles.panelBody}>
        <View style={styles.modeHeader}>
          <View><Text style={styles.bodyTitle}>Perfil de rendimiento</Text><Text style={styles.bodySubtitle}>Los valores son visuales, no miden el hardware.</Text></View>
          <View style={styles.demoPill}><Text style={styles.demoPillText}>DEMO</Text></View>
        </View>
        <View style={styles.modeRow}>
          {modes.map((item) => {
            const selected = mode === item;
            return (
              <Pressable
                key={item}
                onPress={() => onModeChange(item)}
                style={({ pressed }) => [
                  styles.modeButton,
                  selected && { backgroundColor: item === 'Rendimiento' ? '#3b2633' : '#173735', borderColor: accent },
                  pressed && styles.pressed,
                ]}
              >
                <Text style={[styles.modeButtonText, selected && { color: accent }]}>{item}</Text>
              </Pressable>
            );
          })}
        </View>
        <View style={styles.panelActions}>
          <Pressable onPress={() => notify('Perfil guardado en este dispositivo')} style={styles.panelAction}>
            <Feather name="save" size={14} color="#dbe6f1" /><Text style={styles.panelActionText}>Guardar perfil</Text>
          </Pressable>
          <Pressable onPress={() => notify('La sesión sigue activa')} style={styles.panelAction}>
            <Feather name="maximize" size={14} color="#dbe6f1" /><Text style={styles.panelActionText}>Mantener abierto</Text>
          </Pressable>
        </View>
        <Pressable onPress={onClose} style={({ pressed }) => [styles.resumeButton, pressed && styles.pressed]}>
          <Feather name="play" size={15} color="#10252a" />
          <Text style={styles.resumeText}>Volver al juego</Text>
        </Pressable>
      </View>

      {toast ? (
        <View style={[styles.toast, { borderColor: `${accent}80` }]}>
          <Feather name="check-circle" size={14} color={accent} />
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#080c13', justifyContent: 'space-between' },
  topBar: { minHeight: 57, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 8 },
  topIcon: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  topCopy: { flex: 1 },
  topKicker: { color: '#708096', fontSize: 7, letterSpacing: 1.05, fontWeight: '800' },
  topTitle: { color: '#f0f5fa', fontSize: 14, fontWeight: '700', marginTop: 3 },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 20, backgroundColor: '#141d27', paddingHorizontal: 8, paddingVertical: 6 },
  liveDot: { width: 5, height: 5, borderRadius: 4 },
  liveText: { color: '#a3b1c0', fontSize: 6, fontWeight: '800', letterSpacing: 0.7 },
  canvasWrap: { marginHorizontal: 9, borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: '#293946' },
  gameBackground: { width: '100%', aspectRatio: 2.9, justifyContent: 'center', alignItems: 'center', overflow: 'hidden', backgroundColor: '#111720' },
  gameImage: { opacity: 0.94 },
  imageShade: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, backgroundColor: 'rgba(5,10,15,0.18)' },
  topHud: { position: 'absolute', top: 5, left: 5, right: 5, height: 20, borderWidth: 1, borderRadius: 7, backgroundColor: 'rgba(7,12,18,0.82)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 6 },
  miniBrand: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  miniBrandText: { color: '#dbe7f1', fontSize: 5, fontWeight: '800', letterSpacing: 0.5 },
  hudGameName: { color: '#e9eff6', fontSize: 6, letterSpacing: 1, fontWeight: '800' },
  hudStatus: { color: '#9bb1c5', fontSize: 5, fontWeight: '700' },
  sidePanel: { position: 'absolute', top: 24, bottom: 21, width: 59, borderRadius: 9, backgroundColor: 'rgba(7,12,18,0.91)', borderWidth: 1, borderColor: 'rgba(161,189,206,0.25)', padding: 3, justifyContent: 'space-around', zIndex: 2 },
  leftPanel: { left: 4 },
  rightPanel: { right: 4 },
  hudButton: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 6, marginVertical: 1, gap: 1, backgroundColor: 'rgba(34,44,56,0.72)' },
  hudButtonSelected: { backgroundColor: 'rgba(21,85,88,0.8)', borderWidth: 1, borderColor: 'rgba(113,235,219,0.6)' },
  hudButtonLabel: { color: '#c2cdd9', fontSize: 5, fontWeight: '800', letterSpacing: 0.2 },
  hudButtonValue: { color: '#d8f4ed', fontSize: 5, fontWeight: '700' },
  centerReadout: { alignItems: 'center', justifyContent: 'center', marginTop: 7 },
  centerRing: { width: 43, height: 43, borderRadius: 24, borderWidth: 1.5, backgroundColor: 'rgba(4,12,19,0.68)', alignItems: 'center', justifyContent: 'center' },
  fpsNumber: { fontSize: 13, lineHeight: 14, fontWeight: '800' },
  fpsUnit: { color: '#d6e0e8', fontSize: 5, fontWeight: '800', letterSpacing: 0.5 },
  modeCaption: { color: '#e6eff5', fontSize: 5, fontWeight: '800', letterSpacing: 1, marginTop: 4 },
  canvasBottom: { position: 'absolute', bottom: 3, left: 5, right: 5, height: 14, borderRadius: 6, backgroundColor: 'rgba(7,12,18,0.79)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' },
  miniStat: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  miniStatText: { color: '#d4e0e9', fontSize: 5, fontWeight: '600' },
  panelBody: { flex: 1, justifyContent: 'flex-end', paddingHorizontal: 16, paddingTop: 12, paddingBottom: 9, gap: 10 },
  modeHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  bodyTitle: { color: '#edf3f8', fontSize: 12, fontWeight: '700' },
  bodySubtitle: { color: '#7e8da0', fontSize: 8, marginTop: 3 },
  demoPill: { borderRadius: 10, backgroundColor: '#16212b', paddingHorizontal: 7, paddingVertical: 5 },
  demoPillText: { color: '#8395a9', fontSize: 6, fontWeight: '800', letterSpacing: 0.7 },
  modeRow: { flexDirection: 'row', gap: 7 },
  modeButton: { flex: 1, minHeight: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: '#151c25', borderWidth: 1, borderColor: '#28323d' },
  modeButtonText: { color: '#99a6b4', fontSize: 8, fontWeight: '700' },
  panelActions: { flexDirection: 'row', gap: 8 },
  panelAction: { flex: 1, height: 36, borderRadius: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: '#141c25', borderWidth: 1, borderColor: '#273340' },
  panelActionText: { color: '#c3cfdb', fontSize: 8, fontWeight: '600' },
  resumeButton: { minHeight: 42, borderRadius: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, backgroundColor: '#6de7d0' },
  resumeText: { color: '#10252a', fontSize: 10, fontWeight: '800' },
  toast: { position: 'absolute', bottom: 70, left: 22, right: 22, minHeight: 39, borderRadius: 12, borderWidth: 1, backgroundColor: '#111923', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7, paddingHorizontal: 10 },
  toastText: { color: '#e6eef5', fontSize: 8, fontWeight: '600' },
  pressed: { opacity: 0.7 },
});
