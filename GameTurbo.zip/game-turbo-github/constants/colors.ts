/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#27303e',
    tint: '#315f9f',

    // Core surfaces
    background: '#f5f7fb',
    foreground: '#27303e',

    // Cards / elevated surfaces
    card: '#ffffff',
    cardForeground: '#27303e',

    // Primary action color (buttons, links, active states)
    primary: '#315f9f',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e5eefc',
    secondaryForeground: '#315d98',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#f2f5fa',
    mutedForeground: '#77808e',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#e5eefc',
    accentForeground: '#315d98',

    // Destructive actions (delete, error states)
    destructive: '#d95c67',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#e8ebf1',
    input: '#e8ebf1',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
