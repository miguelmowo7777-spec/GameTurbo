# Game Turbo (Android, sin root, con Shizuku)

Kotlin + Jetpack Compose. Redmi A5 / Android 15 Go.

## Compilar con Android Studio
Abrir la carpeta, esperar a Gradle, Build > Build APK(s). Salida: app/build/outputs/apk/debug/app-debug.apk

## Compilar sin PC (GitHub Actions)
1. Crear repositorio en github.com.
2. Subir `GameTurbo.zip` (sin descomprimir) con Add file > Upload files.
3. Add file > Create new file, nombre `.github/workflows/build.yml`, pegar el contenido de ese archivo (esta en el zip).
4. Pestaña Actions > esperar 5-10 min > abrir la ejecucion > Artifacts > GameTurbo-APK.

## Shizuku (sin root)
1. Instalar Shizuku. Activar Opciones de desarrollador (tocar 7 veces la version) y «Depuración inalámbrica» con Wi-Fi.
2. Shizuku > Iniciar mediante depuración inalámbrica > emparejar con codigo > Iniciar.
3. Game Turbo > Config > Autorizar. Tras reiniciar el telefono, repetir «Iniciar».

## Que hace de verdad
- Game Mode por juego (`cmd game set --mode/--downscale/--fps`), limpieza de RAM (`am kill-all`), limitador de segundo plano (appops), apagar ahorro de bateria, modo rendimiento fijo, permisos (`pm grant/revoke`), forzar detencion, lista de procesos (`ps`).
- Monitoreo de CPU, RAM, bateria, temperaturas, FPS (SurfaceFlinger/gfxinfo) y panel flotante.
## Lo que NO se puede sin root
Cambiar frecuencias/governor/nucleos de CPU y GPU. La app solo los muestra (si el kernel los expone).
Algunas ROMs ignoran Game Mode, resolucion/FPS o fixed performance mode.
