package com.gameturbo.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- utilidades
object IconCache { val cache = android.util.LruCache<String, ImageBitmap>(80) }

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val c = LocalContext.current
    val bmp by produceState<ImageBitmap?>(IconCache.cache.get(pkg), pkg) {
        if (value == null) value = withContext(Dispatchers.IO) {
            try { c.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap().also { IconCache.cache.put(pkg, it) } }
            catch (e: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size).clip(RoundedCornerShape(12.dp)))
    else Box(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant))
}

fun launchApp(c: Context, pkg: String) {
    val i = c.packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) else c.toast("Esta app no se puede abrir")
}

fun openOverlaySettings(c: Context) =
    c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

fun openUsageSettings(c: Context) =
    c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

fun openShizuku(c: Context) {
    val i = c.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) else c.toast("Shizuku no está instalado")
}

suspend fun cleanNow(c: Context): String {
    if (!Sh.ready()) return "Requiere Shizuku autorizado"
    return withContext(Dispatchers.IO) {
        val before = SysInfo.ram(c).second
        val r = Ops.clean()
        kotlinx.coroutines.delay(800)
        val after = SysInfo.ram(c).second
        if (!r.ok) "Error: ${r.err.ifEmpty { "el comando falló" }}"
        else "Memoria liberada: ${maxOf(0L, (after - before) shr 20)} MB"
    }
}

fun shMessage(s: ShState): String = when (s) {
    ShState.NOT_INSTALLED -> "Shizuku no está instalado. Instálalo desde GitHub (RikkaApps/Shizuku) o Google Play."
    ShState.NOT_RUNNING -> "Shizuku está instalado pero no iniciado. Ábrelo e inícialo con la depuración inalámbrica."
    ShState.NO_PERMISSION -> "Shizuku funciona. Falta autorizar Game Turbo."
    ShState.DENIED -> "Rechazaste el permiso. En Shizuku > Aplicaciones autorizadas, activa Game Turbo."
    ShState.OLD -> "Tu versión de Shizuku es antigua (pre-v11). Actualízala."
    ShState.READY -> "Conectado · ejecutando como ${Sh.uidLabel()} · API ${Sh.version()}"
}

@Composable
fun ShizukuCard() {
    val c = LocalContext.current
    val s = AppState.sh
    GCard {
        Text("Shizuku", fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Note(shMessage(s), warn = s != ShState.READY && s != ShState.NO_PERMISSION)
        Spacer(Modifier.height(10.dp))
        if (s == ShState.NO_PERMISSION) BigButton("Autorizar Game Turbo") { Sh.request() }
        if (s == ShState.NOT_RUNNING || s == ShState.DENIED || s == ShState.NO_PERMISSION) {
            Spacer(Modifier.height(8.dp)); BigButton("Abrir Shizuku") { openShizuku(c) }
        }
        Spacer(Modifier.height(8.dp))
        BigButton("Comprobar de nuevo") { AppState.refresh(c); c.toast(shMessage(AppState.sh)) }
    }
}

@Composable
fun PermRow(title: String, desc: String, ok: Boolean, tag: String, onClick: () -> Unit) {
    GCard(onClick = if (ok) null else onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("$title  $tag", fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, null,
                tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
fun PermissionsBlock() {
    val c = LocalContext.current
    val tick = AppState.tick
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { AppState.tick++ }
    val ov = remember(tick) { Perms.overlay(c) }
    val us = remember(tick) { Perms.usage(c) }
    val nt = remember(tick) { Perms.notif(c) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PermRow("Mostrar sobre otras apps", "Panel flotante durante la partida.", ov, "(necesario)") { openOverlaySettings(c) }
        PermRow("Acceso de uso", "Detecta qué juego está en primer plano.", us, "(necesario)") { openUsageSettings(c) }
        PermRow("Notificaciones", "Servicio activo y alertas de temperatura.", nt, "(recomendado)") {
            if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

// ---------------------------------------------------------------- asistente inicial
@Composable
fun Onboarding(onDone: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(24.dp)
    ) {
        Text("GAME TURBO / EXPLORE", fontSize = 11.sp, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            when (step) {
                0 -> {
                    Icon(Icons.Filled.CheckCircle, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(16.dp))
                    Text("Configura el acceso a Game Turbo", fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Text("Elige cómo trabajará la app. Sin Shizuku solo podrás ver información; con Shizuku se activan las optimizaciones reales. Esta app no usa root.",
                        fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(16.dp))
                    IntPref("Modo de acceso", listOf("Estándar", "Shizuku"), listOf(0, 1), "access", 1)
                }
                1 -> {
                    Text("Conecta Shizuku", fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(12.dp)); ShizukuCard()
                    Spacer(Modifier.height(8.dp)); ShizukuHelp()
                }
                2 -> {
                    Text("Permisos de Android", fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    Text("Activa cada uno y vuelve. Puedes omitirlos, pero el panel y la detección de juegos los necesitan.",
                        fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp)); PermissionsBlock()
                }
                else -> {
                    Icon(Icons.Filled.Lock, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(16.dp))
                    Text("Tus datos se quedan en tu teléfono", fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Text("Game Turbo no tiene permiso de Internet: sin cuenta, sin anuncios, sin analíticas. Todo funciona sin conexión.",
                        fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center) {
            repeat(4) { Box(Modifier.padding(3.dp).size(if (it == step) 9.dp else 7.dp).clip(CircleShape)
                .background(if (it == step) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { if (step > 0) step-- }, enabled = step > 0, modifier = Modifier.weight(1f)) { Text("Atrás") }
            Button(onClick = { if (step < 3) step++ else onDone() }, modifier = Modifier.weight(1f)) { Text(if (step < 3) "Siguiente" else "Empezar") }
        }
    }
}

@Composable
fun ShizukuHelp() {
    GCard {
        Text("Cómo iniciar Shizuku (sin root, Android 11+)", fontWeight = FontWeight.Medium, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Text("1. Ajustes > Acerca del teléfono: toca 7 veces la versión para activar Opciones de desarrollador.\n" +
            "2. En Opciones de desarrollador activa «Depuración inalámbrica» (con Wi‑Fi conectado).\n" +
            "3. Abre Shizuku > «Iniciar mediante depuración inalámbrica» > Emparejar. En Depuración inalámbrica toca «Emparejar con código» y escribe el código en la notificación de Shizuku.\n" +
            "4. Pulsa «Iniciar» en Shizuku.\n" +
            "5. Vuelve a Game Turbo y pulsa «Autorizar».\n\n" +
            "Tras reiniciar el móvil hay que repetir el paso 4. En Xiaomi, si un comando falla, activa también «Depuración USB (ajustes de seguridad)».",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- juegos
@Composable
fun GameProfileEditor(pkg: String) {
    Column {
        StrPref("Perfil de rendimiento", listOf("Performance", "Balance", "ECO"), listOf("performance", "standard", "battery"),
            "g.$pkg.mode", Prefs.str("def.mode", "performance"))
        IntPref("Escala de resolución (%)", listOf("100", "90", "80", "70", "60"), listOf(100, 90, 80, 70, 60),
            "g.$pkg.scale", Prefs.int("def.scale", 100))
        IntPref("Objetivo de FPS", listOf("Auto", "30", "45", "60", "90"), listOf(0, 30, 45, 60, 90),
            "g.$pkg.fps", Prefs.int("def.fps", 0))
        IntPref("Saturación de pantalla (experimental)", listOf("100%", "120%", "150%"), listOf(100, 120, 150),
            "g.$pkg.sat", Prefs.int("def.sat", 100))
        Text("Los cambios de resolución/FPS los aplica Android mediante Game Mode y la ROM puede ignorarlos. Se restauran al salir del juego.",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun GamesScreen() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val apps by produceState(emptyList<AppEntry>()) { value = withContext(Dispatchers.IO) { loadApps(c) } }
    var games by remember { mutableStateOf(Prefs.games()) }
    var edit by remember { mutableStateOf<String?>(null) }
    var svc by remember { mutableStateOf(GameService.running) }
    val ready = AppState.sh == ShState.READY
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("GAME TURBO / GAME SPACE", fontSize = 11.sp, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1B1245), Color(0xFF0B3C5D), Color(0xFF00B8D4)))).padding(20.dp)) {
            Column {
                Text("Game Turbo", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Panel de juego", color = Color(0xFF9BE8FF), fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Surface(shape = RoundedCornerShape(50), color = Color(0x33FFFFFF)) {
                    Text(if (ready && svc) "Listo para jugar" else if (ready) "Servicio detenido" else "Falta configurar Shizuku",
                        Modifier.padding(horizontal = 14.dp, vertical = 7.dp), color = Color.White, fontSize = 13.sp)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("Perfil actual", modeLabel(Prefs.str("def.mode", "performance")), Modifier.weight(1f))
            Tile("Acceso al sistema", if (ready) "Shizuku · conectado" else "Sin autorizar", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("Limpiar RAM", "Ahora", Modifier.weight(1f)) { scope.launch { c.toast(cleanNow(c)) } }
            Tile("Panel flotante", "Mostrar", Modifier.weight(1f)) {
                if (!Perms.overlay(c)) { c.toast("Concede «Mostrar sobre otras apps»"); openOverlaySettings(c) }
                else { GameService.toggleOverlay(c); svc = true }
            }
            Tile("Servicio auto", if (svc) "Activo" else "Parado", Modifier.weight(1f)) {
                if (svc) { GameService.stop(c); Prefs.put("svc", false); svc = false }
                else if (!Perms.usage(c)) { c.toast("Concede el Acceso de uso"); openUsageSettings(c) }
                else { GameService.start(c); Prefs.put("svc", true); svc = true }
            }
        }
        Text("Mis juegos", fontSize = 20.sp, fontWeight = FontWeight.Medium)
        if (games.isEmpty()) Note("Aún no hay juegos. Añádelos desde la pestaña Apps o desde «Detectados» más abajo.")
        games.forEach { pkg ->
            GCard(onClick = { edit = pkg }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(pkg, 48.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(byPkg[pkg]?.label ?: pkg, fontWeight = FontWeight.Medium)
                        Text("${modeLabel(Prefs.gStr(pkg, "mode", "performance"))} · ${Prefs.g(pkg, "scale", 100)}% · " +
                            (Prefs.g(pkg, "fps", 0).let { if (it == 0) "FPS auto" else "$it FPS" }),
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { launchApp(c, pkg) }) { Icon(Icons.Filled.PlayArrow, "Jugar", tint = MaterialTheme.colorScheme.primary) }
                }
            }
        }
        val detected = apps.filter { it.game && it.pkg !in games }.take(8)
        if (detected.isNotEmpty()) {
            Text("Detectados", fontSize = 20.sp, fontWeight = FontWeight.Medium)
            detected.forEach { a ->
                GCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(a.pkg, 40.dp)
                        Text(a.label, Modifier.weight(1f).padding(horizontal = 12.dp))
                        TextButton(onClick = { Prefs.setGame(a.pkg, true); games = Prefs.games() }) { Text("Agregar") }
                    }
                }
            }
        }
        Spacer(Modifier.height(90.dp))
    }
    edit?.let { p ->
        AlertDialog(onDismissRequest = { edit = null; games = Prefs.games() },
            confirmButton = { TextButton(onClick = { edit = null; games = Prefs.games() }) { Text("Cerrar") } },
            dismissButton = { TextButton(onClick = { Prefs.setGame(p, false); games = Prefs.games(); edit = null }) { Text("Quitar") } },
            title = { Text(byPkg[p]?.label ?: p) },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { GameProfileEditor(p) } })
    }
}

// ---------------------------------------------------------------- lista de apps
@Composable
fun AppListScreen() {
    val c = LocalContext.current
    val apps by produceState<List<AppEntry>?>(null) { value = withContext(Dispatchers.IO) { loadApps(c) } }
    var q by remember { mutableStateOf("") }
    var f by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<AppEntry?>(null) }
    BackHandler(sel != null) { sel = null }
    val s = sel
    if (s != null) { AppDetail(s) { sel = null }; return }
    val all = apps
    val games = Prefs.games()
    val list = all?.filter {
        (q.isBlank() || it.label.contains(q, true) || it.pkg.contains(q, true)) && when (f) {
            0 -> true
            1 -> it.game || it.pkg in games
            2 -> !it.system
            else -> it.system
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenTitle("App list")
        OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar apps") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(50))
        Spacer(Modifier.height(8.dp))
        Choice("", listOf("Todas", "Juegos", "Usuario", "Sistema"), listOf(0, 1, 2, 3), f) { f = it }
        if (list == null) Text("Cargando…", Modifier.padding(16.dp))
        else {
            Text("${list.size} apps", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 100.dp)) {
                items(list, key = { it.pkg }) { a ->
                    GCard(onClick = { sel = a }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(a.pkg)
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(a.label, fontWeight = FontWeight.Medium, maxLines = 1)
                                Text(a.pkg, fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (a.pkg in games) Icon(Icons.Filled.Star, "En Game Space", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppDetail(a: AppEntry, onBack: () -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var isGame by remember { mutableStateOf(a.pkg in Prefs.games()) }
    var limited by remember { mutableStateOf(a.pkg in Prefs.limited()) }
    var perms by remember { mutableStateOf(loadPerms(c, a.pkg)) }
    val ready = AppState.sh == ShState.READY
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle(a.label, onBack)
        GCard {
            Row(verticalAlignment = Alignment.CenterVertically) { AppIcon(a.pkg, 56.dp); Spacer(Modifier.width(12.dp))
                Column { Text(a.label, fontSize = 18.sp, fontWeight = FontWeight.Medium); Text(a.pkg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
            Spacer(Modifier.height(8.dp))
            KV("Versión", a.version.ifEmpty { "N/D" })
            KV("Tipo", if (a.system) "Sistema" else "Instalada por el usuario")
            KV("Categoría", if (a.game) "Juego" else "Otra")
        }
        GCard {
            SwitchRow("Agregar a Game Space", "Detección automática, perfil y panel flotante para esta app.", isGame) {
                isGame = it; Prefs.setGame(a.pkg, it)
            }
            if (isGame) { Spacer(Modifier.height(4.dp)); GameProfileEditor(a.pkg) }
        }
        GCard {
            SwitchRow("Limitar en segundo plano durante partidas", "Usa el limitador de segundo plano (requiere Shizuku y activarlo en Session optimizations).", limited) {
                limited = it; Prefs.setLimited(a.pkg, it)
            }
        }
        GCard {
            Text("Acciones", fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            BigButton("Abrir", a.launchable) { launchApp(c, a.pkg) }
            Spacer(Modifier.height(8.dp))
            BigButton("Forzar detención", ready && !a.system) {
                scope.launch { val r = withContext(Dispatchers.IO) { Ops.forceStop(a.pkg) }; c.toast(if (r.ok) "Detenida" else "Error: ${r.err}") }
            }
            Spacer(Modifier.height(8.dp))
            BigButton("Ajustes de Android de esta app") {
                c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            if (!ready) { Spacer(Modifier.height(8.dp)); Note("Algunas acciones requieren Shizuku autorizado.") }
            if (a.system) { Spacer(Modifier.height(8.dp)); Note("Las apps del sistema no se pueden detener desde aquí por seguridad.") }
        }
        GCard {
            Text("Permisos (en tiempo de ejecución)", fontWeight = FontWeight.Medium)
            if (perms.isEmpty()) Text("Esta app no solicita permisos peligrosos.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            perms.forEach { (p, ok) ->
                SwitchRow(p.substringAfterLast('.'), if (ready) null else "Requiere Shizuku para cambiarlo", ok, ready) { on ->
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { Ops.perm(a.pkg, p, on) }
                        if (!r.ok) c.toast("No permitido por Android: ${r.err}")
                        perms = withContext(Dispatchers.IO) { loadPerms(c, a.pkg) }
                    }
                }
            }
        }
        Spacer(Modifier.height(90.dp))
    }
}
