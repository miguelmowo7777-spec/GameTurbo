package com.gameturbo.app

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.PermissionInfo

data class AppEntry(
    val pkg: String, val label: String, val system: Boolean,
    val game: Boolean, val launchable: Boolean, val version: String
)

@Suppress("DEPRECATION")
private fun isGame(ai: ApplicationInfo) =
    ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0

fun loadApps(c: Context): List<AppEntry> {
    val pm = c.packageManager
    return pm.getInstalledApplications(0).map { ai ->
        val ver = try { pm.getPackageInfo(ai.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        AppEntry(
            ai.packageName, ai.loadLabel(pm).toString(),
            (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0, isGame(ai),
            pm.getLaunchIntentForPackage(ai.packageName) != null, ver
        )
    }.sortedBy { it.label.lowercase() }
}

/** Permisos peligrosos (en tiempo de ejecución) que la app solicita y si están concedidos. */
fun loadPerms(c: Context, pkg: String): List<Pair<String, Boolean>> = try {
    val pm = c.packageManager
    val pi = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
    val req = pi.requestedPermissions ?: emptyArray()
    val fl = pi.requestedPermissionsFlags ?: IntArray(0)
    req.indices.mapNotNull { i ->
        val dangerous = try {
            (pm.getPermissionInfo(req[i], 0).protectionLevel and PermissionInfo.PROTECTION_MASK_BASE) ==
                PermissionInfo.PROTECTION_DANGEROUS
        } catch (e: Exception) { false }
        if (dangerous) req[i] to ((fl.getOrElse(i) { 0 } and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) else null
    }
} catch (e: Exception) { emptyList() }
