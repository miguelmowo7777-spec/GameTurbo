package com.gameturbo.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- Monitoring
@Composable
fun MonitorScreen() {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenTitle("Monitoring")
        Choice("", listOf("Device", "Processes"), listOf(0, 1), tab) { tab = it }
        Spacer(Modifier.height(8.dp))
        if (tab == 0) DeviceTab() else ProcessTab()
    }
}

@Composable
fun DeviceTab() {
    val c = LocalContext.current
    val cpuS = remember { CpuSampler() }
    val fpsS = remember { FpsSampler() }
    val cpuH = remember { mutableStateListOf<Float>() }
    val ramH = remember { mutableStateListOf<Float>() }
    val fpsH = remember { mutableStateListOf<Float>() }
    var temp by remember { mutableStateOf(0f) }
    var batt by remember { mutableIntStateOf(0) }
    var ramTxt by remember { mutableStateOf("…") }
    var cpuNow by remember { mutableStateOf<Int?>(null) }
    var fpsNow by remember { mutableStateOf<Int?>(null) }
    val games = remember { Prefs.games().toList() }
    var target by remember { mutableStateOf(games.firstOrNull()) }
    val info by produceState(emptyList<Pair<String, String>>(), AppState.sh) { value = withContext(Dispatchers.IO) { SysInfo.deviceInfo(c) } }

    LaunchedEffect(target) {
        while (true) {
            withContext(Dispatchers.IO) {
                val b = SysInfo.battery(c); val (rt, ra) = SysInfo.ram(c)
                val cp = cpuS.sample(); val fp = target?.let { fpsS.sample(it) }
                val usedPct = 100f - ra * 100f / rt
                withContext(Dispatchers.Main) {
                    temp = b.temp; batt = b.level; cpuNow = cp ?: cpuNow; fpsNow = fp
                    ramTxt = "${fmtBytes(rt - ra)} / ${fmtBytes(rt)}"
                    fun add(l: MutableList<Float>, v: Float) { l.add(v); if (l.size > 60) l.removeAt(0) }
                    cp?.let { add(cpuH, it.toFloat()) }; add(ramH, usedPct); fp?.let { add(fpsH, it.toFloat()) }
                }
            }
            delay(1000)
        }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 100.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("CPU", cpuNow?.let { "$it %" } ?: "…", Modifier.weight(1f))
                Tile("RAM", ramTxt, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("Temp. batería", "$temp °C", Modifier.weight(1f))
                Tile("Batería", "$batt %", Modifier.weight(1f))
            }
        }
        item {
            GCard {
                Text("FPS", fontWeight = FontWeight.Medium)
                if (games.isEmpty()) Text("Agrega un juego para medir sus FPS.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                else {
                    val labels = games.map { it.substringAfterLast('.') }
                    Choice("Juego a medir (debe estar abierto)", labels, games, target ?: games[0]) { target = it }
                    Text(fpsNow?.let { "$it FPS" } ?: "N/D — ${if (Sh.ready()) "el juego no está en primer plano o no expone frames" else "requiere Shizuku"}",
                        fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    LineChart(fpsH.toList(), 120f, MaterialTheme.colorScheme.primary)
                }
            }
        }
        item { GCard { Text("CPU (%)", fontWeight = FontWeight.Medium); LineChart(cpuH.toList(), 100f, MaterialTheme.colorScheme.primary) } }
        item { GCard { Text("RAM usada (%)", fontWeight = FontWeight.Medium); LineChart(ramH.toList(), 100f, Color(0xFF00B8D4)) } }
        item {
            GCard {
                Text("Device information", fontWeight = FontWeight.Medium, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                info.forEach { (k, v) -> KV(k, v) }
            }
        }
    }
}

fun parseProcs(): List<Triple<Int, Long, String>>? {
    val r = Sh.exec("ps -A -o PID,RSS,NAME")
    if (!r.ok) return null
    return r.out.lines().drop(1).mapNotNull { l ->
        val p = l.trim().split(Regex("\\s+"))
        val pid = p.getOrNull(0)?.toIntOrNull(); val rss = p.getOrNull(1)?.toLongOrNull()
        if (p.size >= 3 && pid != null && rss != null) Triple(pid, rss, p.drop(2).joinToString(" ")) else null
    }.filter { it.third.contains('.') && !it.third.startsWith("/") }.sortedByDescending { it.second }.take(40)
}

@Composable
fun ProcessTab() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    if (!Sh.ready()) { Note("Para consultar procesos Android exige Shizuku autorizado. Sin él, las apps no pueden ver procesos ajenos.", warn = true); return }
    val apps by produceState(emptyList<AppEntry>()) { value = withContext(Dispatchers.IO) { loadApps(c) } }
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    var tick by remember { mutableIntStateOf(0) }
    val procs by poll(4000, null as List<Triple<Int, Long, String>>?) { parseProcs() }
    var kill by remember { mutableStateOf<String?>(null) }
    val list = procs
    if (list == null) { Text("Leyendo procesos…"); return }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 100.dp)) {
        items(list, key = { it.first }) { (pid, rss, name) ->
            val base = name.substringBefore(':')
            val app = byPkg[base]
            GCard(onClick = if (app != null && !app.system && base != c.packageName) ({ kill = base }) else null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(app?.label ?: name, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text("$name · PID $pid", fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${rss / 1024} MB", fontWeight = FontWeight.Medium)
                }
            }
        }
    }
    kill?.let { p ->
        AlertDialog(onDismissRequest = { kill = null },
            title = { Text("Forzar detención") }, text = { Text("¿Detener $p? Perderás lo no guardado en esa app.") },
            confirmButton = { TextButton(onClick = {
                scope.launch { val r = withContext(Dispatchers.IO) { Ops.forceStop(p) }; c.toast(if (r.ok) "Detenida" else "Error: ${r.err}") }
                kill = null; tick++
            }) { Text("Detener") } },
            dismissButton = { TextButton(onClick = { kill = null }) { Text("Cancelar") } })
    }
}

// ---------------------------------------------------------------- Configuración
@Composable
fun SettingsScreen() {
    val c = LocalContext.current
    var svc by remember { mutableStateOf(GameService.running) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle("Configuración")
        ShizukuCard()
        SectionLabel("Permisos")
        PermissionsBlock()
        SectionLabel("Servicio")
        GCard {
            SwitchRow("Servicio de juegos", "Detección automática, optimización y panel flotante.", svc) {
                if (it) {
                    if (Perms.usage(c)) { GameService.start(c); Prefs.put("svc", true); svc = true }
                    else { c.toast("Concede primero el Acceso de uso"); openUsageSettings(c) }
                } else { GameService.stop(c); Prefs.put("svc", false); svc = false }
            }
        }
        ShizukuHelp()
        GCard {
            Text("Game Turbo 1.0", fontWeight = FontWeight.Medium)
            Text("Sin root · sin Internet · sin anuncios. Las funciones que Android no permite sin root se muestran como no disponibles.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            BigButton("Repetir asistente de configuración") { Prefs.put("onboarded", false); AppState.onboarded = false }
        }
        Spacer(Modifier.height(90.dp))
    }
}
