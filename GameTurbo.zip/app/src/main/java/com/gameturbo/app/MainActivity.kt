package com.gameturbo.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val h = Handler(Looper.getMainLooper())
    private fun refresh() { h.post { AppState.refresh(this) } }
    private val l1 = Shizuku.OnBinderReceivedListener { refresh() }
    private val l2 = Shizuku.OnBinderDeadListener { refresh() }
    private val l3 = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        AppState.onboarded = Prefs.bool("onboarded", false)
        Shizuku.addBinderReceivedListenerSticky(l1)
        Shizuku.addBinderDeadListener(l2)
        Shizuku.addRequestPermissionResultListener(l3)
        AppState.refresh(this)
        if (Prefs.bool("svc", false) && AppState.onboarded && !GameService.running && Perms.usage(this)) {
            try { GameService.start(this) } catch (e: Exception) { }
        }
        setContent {
            GameTurboTheme {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    if (!AppState.onboarded) Onboarding { Prefs.put("onboarded", true); AppState.onboarded = true }
                    else Main()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        AppState.refresh(this)
        AppState.tick++
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(l1)
        Shizuku.removeBinderDeadListener(l2)
        Shizuku.removeRequestPermissionResultListener(l3)
        super.onDestroy()
    }
}

@Composable
fun Main() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = { NavBar(tab) { tab = it } }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> GamesScreen()
                1 -> AppListScreen()
                2 -> TuneScreen()
                3 -> MonitorScreen()
                else -> SettingsScreen()
            }
        }
    }
}
