package com.gameturbo.app

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.provider.Settings
import java.io.File

object Perms {
    fun overlay(c: Context) = Settings.canDrawOverlays(c)
    @Suppress("DEPRECATION")
    fun usage(c: Context): Boolean {
        val a = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }
    fun notif(c: Context) = Build.VERSION.SDK_INT < 33 ||
        c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

object SysInfo {
    data class Core(val i: Int, val online: Boolean, val cur: Long?, val max: Long?, val gov: String?)
    data class Batt(val level: Int, val temp: Float, val status: Int, val plugged: Int, val mv: Int, val health: Int, val tech: String)

    fun rd(p: String): String? = try { File(p).readText().trim().ifEmpty { null } } catch (e: Throwable) { null }

    /** Lee archivos del sistema; los que Android bloquea se piden por Shizuku en un solo comando. */
    fun readMany(paths: List<String>): Map<String, String> {
        val res = HashMap<String, String>()
        val miss = ArrayList<String>()
        for (p in paths) { val v = rd(p); if (v != null) res[p] = v else miss.add(p) }
        if (miss.isNotEmpty() && Sh.ready()) {
            val cmd = miss.joinToString("; ") { "echo \"$it=\$(cat $it 2>/dev/null)\"" }
            Sh.exec(cmd).out.lines().forEach { l ->
                val i = l.indexOf('=')
                if (i > 0 && i < l.length - 1) res[l.substring(0, i)] = l.substring(i + 1).trim()
            }
        }
        return res
    }

    fun listDir(p: String): List<String> =
        File(p).list()?.toList() ?: if (Sh.ready()) Sh.exec("ls $p").out.lines().filter { it.isNotBlank() } else emptyList()

    fun cores(): List<Core> {
        val names = listDir("/sys/devices/system/cpu").filter { it.matches(Regex("cpu\\d+")) }
        val n = if (names.isEmpty()) Runtime.getRuntime().availableProcessors() else names.size
        val paths = (0 until n).flatMap { i ->
            val b = "/sys/devices/system/cpu/cpu$i"
            listOf("$b/online", "$b/cpufreq/scaling_cur_freq", "$b/cpufreq/cpuinfo_max_freq", "$b/cpufreq/scaling_governor")
        }
        val m = readMany(paths)
        return (0 until n).map { i ->
            val b = "/sys/devices/system/cpu/cpu$i"
            Core(i, (m["$b/online"] ?: "1") != "0", m["$b/cpufreq/scaling_cur_freq"]?.toLongOrNull(),
                m["$b/cpufreq/cpuinfo_max_freq"]?.toLongOrNull(), m["$b/cpufreq/scaling_governor"])
        }
    }

    private var gpuName: String? = null
    fun gpuRenderer(): String? {
        if (gpuName != null) return gpuName
        if (!Sh.ready()) return null
        val l = Sh.exec("dumpsys SurfaceFlinger | grep -m1 -i 'GLES'").out
        gpuName = l.substringAfter("GLES:", l).trim().ifEmpty { null }
        return gpuName
    }

    /** (actual Hz, máximo Hz) si el kernel lo expone */
    fun gpuFreq(): Pair<Long, Long?>? {
        val d = listDir("/sys/class/devfreq").firstOrNull { it.contains(Regex("gpu|mali|kgsl|g3d", RegexOption.IGNORE_CASE)) } ?: return null
        val m = readMany(listOf("/sys/class/devfreq/$d/cur_freq", "/sys/class/devfreq/$d/max_freq"))
        val cur = m["/sys/class/devfreq/$d/cur_freq"]?.toLongOrNull() ?: return null
        return cur to m["/sys/class/devfreq/$d/max_freq"]?.toLongOrNull()
    }

    fun thermals(): List<Pair<String, Double>> {
        val z = listDir("/sys/class/thermal").filter { it.startsWith("thermal_zone") }.sorted()
        val paths = z.flatMap { listOf("/sys/class/thermal/$it/type", "/sys/class/thermal/$it/temp") }
        val m = readMany(paths)
        return z.mapNotNull { n ->
            val t = m["/sys/class/thermal/$n/temp"]?.toDoubleOrNull() ?: return@mapNotNull null
            val v = if (Math.abs(t) >= 1000) t / 1000.0 else t
            if (v in 1.0..130.0) (m["/sys/class/thermal/$n/type"] ?: n) to v else null
        }
    }

    fun battery(c: Context): Batt {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return Batt(
            if (sc > 0) lv * 100 / sc else lv,
            (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
            i?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0,
            i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0,
            i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0,
            i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0,
            i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "N/D"
        )
    }

    fun statusName(s: Int) = when (s) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Cargando"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Descargando"
        BatteryManager.BATTERY_STATUS_FULL -> "Completa"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Sin cargar"
        else -> "Desconocido"
    }
    fun plugName(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> "Cargador (AC)"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Inalámbrico"
        0 -> "Desconectado"
        else -> "Otro"
    }
    fun healthName(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Buena"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Sobrecalentada"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dañada"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Sobrevoltaje"
        BatteryManager.BATTERY_HEALTH_COLD -> "Fría"
        else -> "Desconocida"
    }

    fun thermalStatus(c: Context): String {
        if (Build.VERSION.SDK_INT < 29) return "N/D"
        return when (c.getSystemService(PowerManager::class.java).currentThermalStatus) {
            0 -> "Normal"; 1 -> "Leve"; 2 -> "Moderado"; 3 -> "Severo"; 4 -> "Crítico"; 5 -> "Emergencia"; 6 -> "Apagado"; else -> "?"
        }
    }

    fun ram(c: Context): Pair<Long, Long> {
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi.totalMem to mi.availMem
    }

    fun storage(): Pair<Long, Long> {
        val s = StatFs(Environment.getDataDirectory().path)
        return s.totalBytes to s.availableBytes
    }

    fun soc(): String {
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL != Build.UNKNOWN)
            return "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}"
        return Build.HARDWARE
    }

    fun deviceInfo(c: Context): List<Pair<String, String>> {
        val (rt, ra) = ram(c); val (st, sa) = storage(); val dm = c.resources.displayMetrics
        val go = c.getSystemService(ActivityManager::class.java).isLowRamDevice
        return listOf(
            "Modelo" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})" + if (go) " · Go" else "",
            "Parche de seguridad" to Build.VERSION.SECURITY_PATCH,
            "SoC" to soc(),
            "Hardware" to Build.HARDWARE,
            "Arquitectura (ABI)" to Build.SUPPORTED_ABIS.joinToString(),
            "Núcleos" to Runtime.getRuntime().availableProcessors().toString(),
            "GPU" to (gpuRenderer() ?: "Requiere Shizuku"),
            "RAM" to "${fmtBytes(ra)} libres de ${fmtBytes(rt)}",
            "Almacenamiento" to "${fmtBytes(sa)} libres de ${fmtBytes(st)}",
            "Pantalla" to "${dm.widthPixels}x${dm.heightPixels} · ${dm.densityDpi} dpi",
            "Kernel" to (System.getProperty("os.version") ?: "N/D")
        )
    }
}

class CpuSampler {
    private var pt = 0L
    private var pi = 0L
    fun sample(): Int? {
        val raw = SysInfo.rd("/proc/stat")?.lineSequence()?.firstOrNull()
            ?: (if (Sh.ready()) Sh.exec("head -n1 /proc/stat").out else null)
            ?: return null
        val v = raw.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (v.size < 5) return null
        val idle = v[3] + v[4]
        val total = v.take(8).sum()
        val dt = total - pt; val di = idle - pi
        val first = pt == 0L
        pt = total; pi = idle
        return if (first || dt <= 0) null else (100 * (dt - di) / dt).toInt().coerceIn(0, 100)
    }
}

/** FPS reales vía SurfaceFlinger (juegos) con respaldo en gfxinfo. Devuelve null si no se puede medir. */
class FpsSampler {
    private var layer: String? = null
    private var layerPkg: String? = null
    private var pf = -1L
    private var pt = 0L

    fun sample(pkg: String): Int? {
        if (!Sh.ready() || !Ops.safe(pkg)) return null
        if (layerPkg != pkg) { layerPkg = pkg; layer = null; pf = -1 }
        if (layer == null) {
            val l = Sh.exec("dumpsys SurfaceFlinger --list | grep -F '$pkg'").out.lines().filter { it.isNotBlank() }
            layer = l.firstOrNull { it.startsWith("SurfaceView") && !it.contains("Background") } ?: l.firstOrNull()
        }
        val ly = layer
        if (ly != null && !ly.contains("'")) {
            val out = Sh.exec("dumpsys SurfaceFlinger --latency '$ly'").out.lines()
            val ts = out.drop(1).mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
                .filter { it > 0 && it < Long.MAX_VALUE / 2 }
            if (ts.size > 2) {
                val last = ts.last()
                if (last < System.nanoTime() - 2_000_000_000L) return 0
                return ts.count { it > last - 1_000_000_000L }
            } else layer = null
        }
        val o = Sh.exec("dumpsys gfxinfo $pkg | grep -m1 'Total frames rendered'").out
        val f = Regex("(\\d+)").find(o)?.value?.toLongOrNull() ?: return null
        val now = System.nanoTime()
        val r = if (pf >= 0 && f > pf && now > pt) ((f - pf) * 1e9 / (now - pt)).toInt() else null
        pf = f; pt = now
        return r
    }
}

/** Detecta la app en primer plano con el Acceso de uso (sin Shizuku). */
class FgTracker(private val c: Context) {
    private var last = System.currentTimeMillis() - 2 * 3600_000L
    var cur: String? = null
    fun update(): String? {
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(last, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) cur = e.packageName
            else if (e.eventType == UsageEvents.Event.ACTIVITY_PAUSED && e.packageName == cur) cur = null
        }
        last = now - 1000
        return cur
    }
}

fun fmtKhz(v: Long?): String =
    if (v == null) "N/D" else if (v >= 1_000_000) String.format(java.util.Locale.US, "%.2f GHz", v / 1e6) else "${v / 1000} MHz"

fun fmtBytes(b: Long): String =
    if (b >= (1L shl 30)) String.format(java.util.Locale.US, "%.1f GB", b / 1073741824.0) else "${b shr 20} MB"
