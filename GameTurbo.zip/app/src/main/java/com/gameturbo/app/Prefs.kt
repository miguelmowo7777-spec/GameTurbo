package com.gameturbo.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("gt", Context.MODE_PRIVATE) }

    fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun int(k: String, d: Int) = sp.getInt(k, d)
    fun str(k: String, d: String) = sp.getString(k, d) ?: d

    fun put(k: String, v: Any) {
        val e = sp.edit()
        when (v) {
            is Boolean -> e.putBoolean(k, v)
            is Int -> e.putInt(k, v)
            is String -> e.putString(k, v)
            else -> {}
        }
        e.apply()
    }

    private fun set(k: String): Set<String> = sp.getStringSet(k, emptySet()) ?: emptySet()
    private fun toggle(k: String, p: String, on: Boolean) {
        val s = set(k).toMutableSet(); if (on) s.add(p) else s.remove(p)
        sp.edit().putStringSet(k, s).apply()
    }

    fun games() = set("games")
    fun setGame(p: String, on: Boolean) = toggle("games", p, on)
    fun limited() = set("limited")
    fun setLimited(p: String, on: Boolean) = toggle("limited", p, on)

    /** Valor por juego con respaldo en el valor global "def.*" */
    fun g(pkg: String, k: String, d: Int) = sp.getInt("g.$pkg.$k", sp.getInt("def.$k", d))
    fun gStr(pkg: String, k: String, d: String) = sp.getString("g.$pkg.$k", sp.getString("def.$k", d)) ?: d
}

fun modeLabel(m: String) = when (m) { "performance" -> "Performance"; "battery" -> "ECO"; else -> "Balance" }
