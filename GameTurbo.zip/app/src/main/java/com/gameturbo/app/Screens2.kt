package com.gameturbo.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun TuneScreen() {
    var sub by remember { mutableStateOf("") }
    BackHandler(sub.isNotEmpty()) { sub = "" }
    val back = { sub = "" }
    when (sub) {
        "render" -> Page("Render & color", back) { RenderPage() }
        "auto" -> Page("Automation & protection", back) { AutomationPage() }
        "session" -> Page("Session optimizations", back) { SessionPage() }
        "cpugpu" -> Page("CPU & GPU", back) { CpuGpuPage() }
        "cores" -> Page("Full CPU mode control", back) { CoresPage() }
        "thermal" -> Page("Charging & thermal", back) { ThermalPage() }
        "custom" -> Page("Customization", back) { CustomPage() }
        else -> Page("Ajustes", null) {
            val items = listOf(
                "render" to "Render & color" to "Resolución, FPS y saturación por defecto",
                "auto" to "Automation & protection" to "ECO, protección térmica y alertas",
                "session" to "Session optimizations" to "Qué se aplica al abrir un juego",
                "cpugpu" to "CPU & GPU" to "Información, frecuencias y perfil de rendimiento",
                "cores" to "Full CPU mode control" to "Estado y frecuencia de cada núcleo",
                "thermal" to "Charging & thermal" to "Carga, batería y temperaturas",
                "custom" to "Customization" to "Tema, color, tamaño de texto"
            )
            items.forEach { (kt, desc) ->
                val (key, title) = kt
                GCard(onClick = { sub = key }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Filled.KeyboardArrowRight, null)
                    }
                }
            }
        }
    }
}

@Composable
fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle(title, onBack)
        content()
        Spacer(Modifier.height(90.dp))
    }
}

@Composable
fun RenderPage() {
    Note("Valores por defecto para todos los juegos. Cada juego puede cambiarlos en su perfil (Apps o Juegos).")
    GCard {
        IntPref("Escala de resolución (%)", listOf("100", "90", "80", "70", "60"), listOf(100, 90, 80, 70, 60), "def.scale", 100)
        IntPref("Objetivo de FPS", listOf("Auto", "30", "45", "60", "90"), listOf(0, 30, 45, 60, 90), "def.fps", 0)
        Text("Se aplican con «cmd game» (Game Mode de Android). Si la ROM no lo soporta, el sistema lo ignora; Game Turbo no lo simula.",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    GCard {
        IntPref("Saturación (experimental)", listOf("100%", "120%", "150%"), listOf(100, 120, 150), "def.sat", 100)
        Text("Usa SurfaceFlinger. Depende de la ROM y se restaura a 100% al salir del juego.",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun AutomationPage() {
    val c = LocalContext.current
    var svc by remember { mutableStateOf(Prefs.bool("svc", false)) }
    SwitchRow("Servicio automático", "Detecta tus juegos y aplica el perfil solo. Necesita Acceso de uso.", svc) {
        svc = it; Prefs.put("svc", it)
        if (it) { if (Perms.usage(c)) GameService.start(c) else { c.toast("Concede el Acceso de uso"); openUsageSettings(c) } } else GameService.stop(c)
    }
    if (!Perms.usage(c)) Note("Falta el Acceso de uso: sin él no se puede detectar el juego en primer plano.", warn = true)
    SectionLabel("Auto mode")
    GCard {
        SwitchPref("ECO con pantalla apagada", "Si apagas la pantalla durante la partida, pasa a modo ECO.", "a.ecoScreen", true)
        SwitchPref("ECO con batería baja", "Pasa a ECO cuando la batería baja del nivel elegido (sin cargador).", "a.ecoLow", true)
        IntPref("Nivel de batería baja (%)", listOf("10", "15", "20", "30"), listOf(10, 15, 20, 30), "a.lowLvl", 15)
        SwitchPref("Bajar a Balance si se calienta", "Si el perfil es Performance y la batería supera el umbral, usa Balance.", "a.hot", true)
        IntPref("Umbral de calor (°C)", listOf("40", "42", "44", "46", "48"), listOf(40, 42, 44, 46, 48), "a.hotT", 44)
    }
    SectionLabel("Protección global")
    GCard {
        SwitchPref("Alertas de temperatura", "Notificación cuando la batería supera el límite.", "a.alerts", true)
        IntPref("Límite de alerta (°C)", listOf("40", "42", "45", "48"), listOf(40, 42, 45, 48), "a.alertT", 42)
        SwitchPref("Panel flotante en partida", "Muestra FPS, CPU, RAM y temperatura sobre el juego.", "ov.on", true)
    }
    Note("Seguridad: Game Turbo no escribe en /sys ni toca frecuencias. Solo usa funciones que Android permite a Shizuku y restaura todo al salir del juego.")
}

@Composable
fun SessionPage() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    GCard {
        SwitchPref("Performance optimization", "Pide a Android el modo de juego del perfil (resolución y FPS configurados) mientras juegas.", "o.perf", true)
        SwitchPref("Clean Memory", "Cierra procesos en caché al empezar la partida.", "o.clean", true)
        SwitchPref("Background Limiter", "Restringe en segundo plano las apps marcadas en su ficha (Apps).", "o.bg", false)
        SwitchPref("Turn off Battery Saver", "Desactiva el ahorro de batería de Android al empezar.", "o.saver", true)
        SwitchPref("Fixed performance mode (experimental)", "Pide rendimiento sostenido al servicio de energía. Muchas ROMs lo ignoran; se desactiva al salir.", "o.fixed", false)
    }
    BigButton("Limpiar memoria ahora") { scope.launch { c.toast(cleanNow(c)) } }
    GCard {
        Text("Qué hace sin root", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Text("Todo se ejecuta con Shizuku (permisos de ADB) y solo si Android lo acepta. Cada cambio se revierte al cerrar el juego.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Text("Necesita root (no posible aquí)", fontWeight = FontWeight.Medium)
        Text("Límites de frecuencia de CPU/GPU, governor, prioridad de procesos, scheduler y ajustes del kernel. Game Turbo no los muestra como activos porque no se pueden cambiar.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

data class Snap(val cores: List<SysInfo.Core> = emptyList(), val cpu: Int? = null, val gpu: Pair<Long, Long?>? = null,
                val temps: List<Pair<String, Double>> = emptyList())

@Composable
fun CpuGpuPage() {
    val c = LocalContext.current
    val sampler = remember { CpuSampler() }
    val snap by poll(2000, Snap()) { Snap(SysInfo.cores(), sampler.sample(), SysInfo.gpuFreq(), SysInfo.thermals()) }
    val gpuName by produceState<String?>(null, AppState.sh) { value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { SysInfo.gpuRenderer() } }
    GCard {
        Text("Procesador", fontWeight = FontWeight.Medium, fontSize = 16.sp)
        KV("SoC", SysInfo.soc()); KV("Arquitectura", android.os.Build.SUPPORTED_ABIS.joinToString())
        KV("Núcleos", snap.cores.size.toString()); KV("Uso de CPU", snap.cpu?.let { "$it %" } ?: "midiendo…")
        KV("Governor", snap.cores.firstNotNullOfOrNull { it.gov } ?: "No legible")
        KV("Frecuencia máx.", fmtKhz(snap.cores.mapNotNull { it.max }.maxOrNull()))
    }
    GCard {
        Text("GPU", fontWeight = FontWeight.Medium, fontSize = 16.sp)
        KV("Modelo", gpuName ?: "Requiere Shizuku")
        KV("Frecuencia", snap.gpu?.let { "${fmtKhz(it.first / 1000)}" + (it.second?.let { m -> " / ${fmtKhz(m / 1000)}" } ?: "") } ?: "No expuesta por el kernel")
    }
    GCard {
        Text("Temperaturas", fontWeight = FontWeight.Medium, fontSize = 16.sp)
        if (snap.temps.isEmpty()) Text("No disponibles sin Shizuku o bloqueadas por la ROM.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        snap.temps.take(8).forEach { (n, t) -> KV(n, String.format("%.1f °C", t)) }
    }
    GCard {
        StrPref("Perfil de rendimiento por defecto", listOf("Performance", "Balance", "ECO"), listOf("performance", "standard", "battery"), "def.mode", "performance")
        Text("Se aplica con Game Mode de Android. Las frecuencias de CPU/GPU son de solo lectura: cambiarlas requiere root.",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun CoresPage() {
    val sampler = remember { CpuSampler() }
    val snap by poll(1500, Snap()) { Snap(SysInfo.cores(), sampler.sample()) }
    Note("Estado en tiempo real, solo lectura. Apagar núcleos o fijar frecuencias requiere root y no está disponible.")
    if (snap.cores.isEmpty()) Text("Leyendo núcleos…")
    snap.cores.forEach { co ->
        GCard {
            Row {
                Text("CPU ${co.i}", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                Text(if (co.online) "En línea" else "Apagado", fontSize = 12.sp,
                    color = if (co.online) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(6.dp))
            val frac = if (co.cur != null && co.max != null && co.max > 0) (co.cur.toFloat() / co.max).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            Text("${fmtKhz(co.cur)} / ${fmtKhz(co.max)} · ${co.gov ?: "governor N/D"}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    GCard { StrPref("Perfil global", listOf("Performance", "Balance", "ECO"), listOf("performance", "standard", "battery"), "def.mode", "performance") }
}

@Composable
fun ThermalPage() {
    val c = LocalContext.current
    val b by poll(2000, SysInfo.battery(c)) { SysInfo.battery(c) }
    val temps by poll(5000, emptyList<Pair<String, Double>>()) { SysInfo.thermals() }
    val limit = Prefs.int("a.alertT", 42)
    if (b.temp >= limit) Note("Temperatura elevada: ${b.temp} °C (límite $limit °C). Pausa la partida o deja enfriar el teléfono.", warn = true)
    GCard {
        Text("${b.level} %", fontSize = 40.sp, fontWeight = FontWeight.Medium)
        LinearProgressIndicator(progress = { b.level / 100f }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        KV("Estado", SysInfo.statusName(b.status)); KV("Cargador", SysInfo.plugName(b.plugged))
        KV("Temperatura batería", "${b.temp} °C"); KV("Voltaje", "${b.mv} mV")
        KV("Salud", SysInfo.healthName(b.health)); KV("Tecnología", b.tech)
        KV("Estado térmico Android", SysInfo.thermalStatus(c))
    }
    GCard {
        Text("Zonas térmicas", fontWeight = FontWeight.Medium)
        if (temps.isEmpty()) Text("No disponibles (requiere Shizuku o la ROM las bloquea).", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        temps.take(10).forEach { (n, t) -> KV(n, String.format("%.1f °C", t)) }
    }
    GCard {
        SwitchPref("Alertas de temperatura", "Notificación al superar el límite (requiere el servicio activo).", "a.alerts", true)
        IntPref("Límite (°C)", listOf("40", "42", "45", "48"), listOf(40, 42, 45, 48), "a.alertT", 42)
    }
}

@Composable
fun CustomPage() {
    GCard {
        IntPref("Tema", listOf("Sistema", "Claro", "Oscuro"), listOf(0, 1, 2), "theme", 0) { AppState.themeTick++ }
        IntPref("Color de acento", listOf("Azul", "Violeta", "Verde"), listOf(0, 1, 2), "accent", 0) { AppState.themeTick++ }
        IntPref("Tamaño de texto (accesibilidad)", listOf("Normal", "Grande", "Muy grande"), listOf(100, 115, 130), "font", 100) { AppState.themeTick++ }
    }
    Note("La personalización por juego (perfil, resolución, FPS, saturación) está en la ficha de cada app, en Apps o tocando el juego en Juegos.")
}
