package com.gameturbo.app

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.lang.reflect.Method
import java.util.Locale

enum class ShState { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, DENIED, READY, OLD }

data class ExecResult(val ok: Boolean, val out: String, val err: String)

/** Integración con la API oficial de Shizuku. Nada se simula: si no está autorizado, no se ejecuta. */
object Sh {
    const val REQ = 4821

    fun installed(c: Context) = try {
        c.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
    } catch (e: Exception) { false }

    fun running() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun state(c: Context): ShState {
        if (!running()) return if (installed(c)) ShState.NOT_RUNNING else ShState.NOT_INSTALLED
        return try {
            if (Shizuku.isPreV11()) ShState.OLD
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) ShState.READY
            else if (Shizuku.shouldShowRequestPermissionRationale()) ShState.DENIED
            else ShState.NO_PERMISSION
        } catch (e: Throwable) { ShState.NOT_RUNNING }
    }

    fun ready() = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request() { try { Shizuku.requestPermission(REQ) } catch (e: Throwable) { } }

    fun uidLabel() = try {
        when (val u = Shizuku.getUid()) { 0 -> "root"; 2000 -> "ADB (shell)"; else -> "uid $u" }
    } catch (e: Throwable) { "?" }

    fun version() = try { Shizuku.getVersion() } catch (e: Throwable) { -1 }

    private val newProc: Method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    /** Ejecuta un comando shell con los privilegios de Shizuku. NO llamar desde el hilo principal. */
    fun exec(cmd: String): ExecResult {
        if (!ready()) return ExecResult(false, "", "Shizuku no está autorizado")
        return try {
            val p = newProc.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            val code = p.waitFor()
            ExecResult(code == 0, out.trim(), err.trim())
        } catch (e: Throwable) {
            ExecResult(false, "", e.cause?.message ?: e.message ?: "error desconocido")
        }
    }
}

/** Operaciones reales que Android permite al usuario "shell" (sin root). */
object Ops {
    fun safe(p: String) = p.matches(Regex("[A-Za-z0-9._]+"))

    fun setGameMode(pkg: String, mode: String, scale: Int, fps: Int): ExecResult {
        if (!safe(pkg)) return ExecResult(false, "", "paquete inválido")
        val sb = StringBuilder("cmd game set --mode $mode")
        if (scale in 1..99) sb.append(String.format(Locale.US, " --downscale %.2f", scale / 100.0))
        if (fps > 0) sb.append(" --fps $fps")
        sb.append(" --user 0 $pkg")
        val r = Sh.exec(sb.toString())
        if (r.ok && !r.out.contains("rror", true)) return r
        // Reintento solo con el modo (algunas ROMs no aceptan downscale/fps)
        return Sh.exec("cmd game set --mode $mode --user 0 $pkg")
    }

    fun resetGame(pkg: String) = if (safe(pkg)) Sh.exec("cmd game reset --user 0 $pkg") else ExecResult(false, "", "paquete inválido")
    fun clean() = Sh.exec("am kill-all")
    fun forceStop(pkg: String) = if (safe(pkg)) Sh.exec("am force-stop $pkg") else ExecResult(false, "", "paquete inválido")
    fun saverOff() = Sh.exec("settings put global low_power 0")
    fun fixed(on: Boolean) = Sh.exec("cmd power set-fixed-performance-mode-enabled $on")
    fun saturation(v: Float) = Sh.exec(String.format(Locale.US, "service call SurfaceFlinger 1022 f %.2f", v))

    fun limitBg(pkg: String, on: Boolean): ExecResult {
        if (!safe(pkg)) return ExecResult(false, "", "paquete inválido")
        val m = if (on) "ignore" else "allow"
        return Sh.exec("cmd appops set $pkg RUN_IN_BACKGROUND $m; cmd appops set $pkg RUN_ANY_IN_BACKGROUND $m")
    }

    fun perm(pkg: String, perm: String, grant: Boolean): ExecResult {
        if (!safe(pkg) || !safe(perm)) return ExecResult(false, "", "valor inválido")
        return Sh.exec("pm ${if (grant) "grant" else "revoke"} --user 0 $pkg $perm")
    }
}
