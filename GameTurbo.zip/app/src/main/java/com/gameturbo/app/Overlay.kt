package com.gameturbo.app

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class OvStats(
    val fps: Int?, val cpu: Int?, val ram: Int, val temp: Float, val batt: Int,
    val mode: String, val scale: Int, val fpsTarget: Int, val inGame: Boolean
)

/** Medidor circular de neón (como los de CPU/GPU del video). */
class GaugeView(ctx: Context) : View(ctx) {
    var value = 0f
    var color = 0xFF00E676.toInt()
    var label = ""
    var text = "--"
    var unit = "%"

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x33FFFFFF }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f; val cy = height / 2f
        val sw = s * 0.07f
        val r = s / 2f - sw * 1.6f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        track.strokeWidth = sw
        c.drawArc(rect, 135f, 270f, false, track)
        val sweep = 270f * value.coerceIn(0f, 1f)
        glow.strokeWidth = sw * 2.4f; glow.color = color; glow.alpha = 55
        c.drawArc(rect, 135f, sweep, false, glow)
        arc.strokeWidth = sw; arc.color = color
        c.drawArc(rect, 135f, sweep, false, arc)
        big.textSize = s * 0.27f
        c.drawText(text, cx, cy + s * 0.06f, big)
        small.textSize = s * 0.10f; small.color = color
        c.drawText(unit, cx, cy + s * 0.20f, small)
        small.color = 0xAAFFFFFF.toInt()
        c.drawText(label, cx, cy + s * 0.40f, small)
    }
}

/**
 * Panel de juego de neón: burbuja flotante con los FPS que se expande a un panel completo
 * (medidores, perfil/resolución/FPS, interruptores y barra de estado).
 */
class NeonOverlay(
    private val ctx: Context,
    private val onClean: () -> Unit,
    private val onMode: () -> Unit,
    private val onScale: () -> Unit,
    private val onFps: () -> Unit,
    private val onHide: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val ui = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var panel: View? = null
    private var bx = dp(12)
    private var by = dp(90)
    private var last: OvStats? = null

    private var gCpu: GaugeView? = null
    private var gRam: GaugeView? = null
    private var pillMode: TextView? = null
    private var pillFps: TextView? = null
    private var cardMode: TextView? = null
    private var cardScale: TextView? = null
    private var cardFps: TextView? = null
    private var status: TextView? = null
    private val tiles = HashMap<String, TextView>()
    private val tileOn = HashMap<String, Boolean>()

    private fun accent(mode: String) = when (mode) {
        "performance" -> 0xFFFF1744.toInt()
        "battery" -> 0xFF00B0FF.toInt()
        else -> 0xFF00E676.toInt()
    }

    private fun bg(fill: Int, stroke: Int, r: Float = 14f, sw: Int = 1) =
        GradientDrawable().apply { setColor(fill); cornerRadius = r * d; setStroke(dp(sw), stroke) }

    fun show() { if (bubble == null && panel == null) showBubble() }

    fun destroy() {
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null; panel = null
    }

    // ---------------------------------------------------------------- burbuja
    private fun showBubble() {
        val tv = TextView(ctx).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            text = last?.fps?.toString() ?: "⚡"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xE6081018.toInt()); setStroke(dp(2), accent(last?.mode ?: "standard"))
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(54), dp(54), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = bx; y = by }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); bx = lp.x; by = lp.y
                        try { wm.updateViewLayout(tv, lp) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) expand()
            }
            true
        }
        try { wm.addView(tv, lp); bubble = tv } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- panel completo
    private fun expand() {
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null
        val v = buildPanel()
        val lp = WindowManager.LayoutParams(
            MATCH, MATCH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(v, lp); panel = v } catch (e: Exception) { showBubble(); return }
        last?.let { update(it) }
        if (Sh.ready()) Thread {
            val dnd = Sh.exec("settings get global zen_mode").out.trim().let { it.isNotEmpty() && it != "0" && it != "null" }
            val wifi = Sh.exec("settings get global wifi_on").out.trim() == "1"
            val rot = Sh.exec("settings get system accelerometer_rotation").out.trim() == "1"
            ui.post { setTile("dnd", dnd); setTile("wifi", wifi); setTile("rot", rot) }
        }.start()
    }

    private fun collapse() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null; gCpu = null; gRam = null; pillMode = null; pillFps = null
        cardMode = null; cardScale = null; cardFps = null; status = null; tiles.clear()
        showBubble()
    }

    private fun setTile(key: String, on: Boolean) {
        tileOn[key] = on
        tiles[key]?.apply {
            background = if (on) bg(0xFF0B6B35.toInt(), 0xFF00E676.toInt(), 14f, 2) else bg(0xFF1B222B.toInt(), 0xFF2E3844.toInt(), 14f, 1)
        }
    }

    private fun toggle(key: String, cmdOn: String, cmdOff: String) {
        if (!Sh.ready()) { Toast.makeText(ctx, "Requiere Shizuku autorizado", Toast.LENGTH_SHORT).show(); return }
        val on = !(tileOn[key] ?: false)
        setTile(key, on)
        Thread { Sh.exec(if (on) cmdOn else cmdOff) }.start()
    }

    private fun buildPanel(): View {
        val land = ctx.resources.displayMetrics.let { it.widthPixels > it.heightPixels }
        val root = FrameLayout(ctx).apply { setBackgroundColor(0xF2050A10.toInt()); isClickable = true }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(30), dp(16), dp(12)) }

        fun lay(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }

        // barra superior
        fun round(t: String, a: () -> Unit) = TextView(ctx).apply {
            text = t; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = bg(0xFF1B222B.toInt(), 0xFF2E3844.toInt(), 22f)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(8) }
            setOnClickListener { a() }
        }
        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(round("⌂") {
            ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); collapse()
        })
        top.addView(round("⚡") { onClean(); Toast.makeText(ctx, "Limpiando memoria…", Toast.LENGTH_SHORT).show() })
        top.addView(round("◐") { onMode() })
        top.addView(round("✕") { onHide() })
        top.addView(View(ctx).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        top.addView(round("⌄") { collapse() })

        // herramientas (izquierda)
        fun card(click: () -> Unit) = TextView(ctx).apply {
            textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(14), dp(12), dp(14), dp(12))
            background = bg(0xFF151B23.toInt(), 0xFF26303B.toInt()); setOnClickListener { click() }
        }
        cardMode = card { onMode() }; cardScale = card { onScale() }; cardFps = card { onFps() }
        val left = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(cardMode, lay(MATCH, WRAP)); addView(cardScale, lay(MATCH, WRAP)); addView(cardFps, lay(MATCH, WRAP))
        }

        // medidores (centro)
        fun pill(click: () -> Unit) = TextView(ctx).apply {
            textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(18), dp(7), dp(18), dp(7)); setOnClickListener { click() }
        }
        gCpu = GaugeView(ctx).apply { label = "CPU" }
        gRam = GaugeView(ctx).apply { label = "RAM" }
        pillMode = pill { onMode() }; pillFps = pill { }
        fun gcol(g: GaugeView, p: TextView) = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(g, LinearLayout.LayoutParams(dp(130), dp(130)))
            addView(p, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        }
        val center = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(gcol(gCpu!!, pillMode!!), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(gcol(gRam!!, pillFps!!), LinearLayout.LayoutParams(0, WRAP, 1f))
        }

        // interruptores (derecha)
        fun tile(key: String, icon: String, name: String, click: () -> Unit) = TextView(ctx).apply {
            text = "$icon\n$name"; gravity = Gravity.CENTER; textSize = 12f; setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(14)); setOnClickListener { click() }
            background = bg(0xFF1B222B.toInt(), 0xFF2E3844.toInt()); tiles[key] = this
        }
        val tClean = tile("clean", "🧹", "Limpiar RAM") { onClean(); Toast.makeText(ctx, "Limpiando memoria…", Toast.LENGTH_SHORT).show() }
        val tDnd = tile("dnd", "🔕", "No molestar") { toggle("dnd", "cmd notification set_dnd priority", "cmd notification set_dnd off") }
        val tWifi = tile("wifi", "📶", "Wi‑Fi") { toggle("wifi", "svc wifi enable", "svc wifi disable") }
        val tRot = tile("rot", "🔄", "Rotación") { toggle("rot", "settings put system accelerometer_rotation 1", "settings put system accelerometer_rotation 0") }
        fun row(a: View, b: View) = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(a, lay(0, WRAP, 1f)); addView(b, lay(0, WRAP, 1f))
        }
        val right = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(tClean, tDnd), lay(MATCH, WRAP)); addView(row(tWifi, tRot), lay(MATCH, WRAP))
        }

        val body = LinearLayout(ctx).apply {
            orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            if (land) {
                addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(center, LinearLayout.LayoutParams(0, WRAP, 1.5f))
                addView(right, LinearLayout.LayoutParams(0, WRAP, 1f))
            } else {
                addView(center, lay(MATCH, WRAP)); addView(left, lay(MATCH, WRAP)); addView(right, lay(MATCH, WRAP))
            }
        }
        val scroll = ScrollView(ctx).apply { isFillViewport = true; addView(body, FrameLayout.LayoutParams(MATCH, MATCH)) }

        status = TextView(ctx).apply {
            gravity = Gravity.CENTER; textSize = 12f; setTextColor(0xFF9BE8FF.toInt()); typeface = Typeface.MONOSPACE
            setPadding(dp(16), dp(8), dp(16), dp(8)); background = bg(0xFF0B1219.toInt(), 0xFF00E5FF.toInt(), 18f)
        }
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(status, LinearLayout.LayoutParams(WRAP, WRAP).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        for (k in listOf("clean", "dnd", "wifi", "rot")) setTile(k, tileOn[k] ?: false)
        return root
    }

    // ---------------------------------------------------------------- actualización (hilo principal)
    fun update(s: OvStats) {
        last = s
        val c = accent(s.mode)
        bubble?.apply {
            text = s.fps?.toString() ?: "⚡"
            (background as? GradientDrawable)?.setStroke(dp(2), c)
        }
        if (panel == null) return
        gCpu?.apply { value = (s.cpu ?: 0) / 100f; color = c; text = s.cpu?.toString() ?: "--"; unit = "%"; invalidate() }
        gRam?.apply { value = s.ram / 100f; color = c; text = s.ram.toString(); unit = "%"; invalidate() }
        pillMode?.apply { text = modeLabel(s.mode).uppercase(); setTextColor(c); background = bg(0x22000000, c, 16f, 2) }
        pillFps?.apply { text = "FPS ${s.fps ?: "—"}"; setTextColor(c); background = bg(0x22000000, c, 16f, 2) }
        val g = if (s.inGame) "" else "\n(abre un juego de tu lista)"
        cardMode?.text = "PERFIL\n${modeLabel(s.mode)}$g"
        cardScale?.text = "RESOLUCIÓN\n${s.scale}%"
        cardFps?.text = "OBJETIVO DE FPS\n${if (s.fpsTarget == 0) "Auto" else s.fpsTarget.toString()}"
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        status?.text = "$t · ${s.batt}% · ${s.temp}°C · RAM ${s.ram}%"
    }
}
