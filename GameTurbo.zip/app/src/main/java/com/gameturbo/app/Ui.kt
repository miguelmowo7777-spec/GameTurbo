package com.gameturbo.app

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object AppState {
    var sh by mutableStateOf(ShState.NOT_RUNNING)
    var tick by mutableIntStateOf(0)
    var themeTick by mutableIntStateOf(0)
    var onboarded by mutableStateOf(false)
    fun refresh(c: Context) { sh = Sh.state(c) }
}

fun Context.toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

val Accents = listOf(Color(0xFF3B5FA8), Color(0xFF7B4FD0), Color(0xFF1F8A5B))

@Composable
fun GameTurboTheme(content: @Composable () -> Unit) {
    val tk = AppState.themeTick
    val mode = remember(tk) { Prefs.int("theme", 0) }
    val acc = remember(tk) { Prefs.int("accent", 0).coerceIn(0, 2) }
    val fs = remember(tk) { Prefs.int("font", 100) / 100f }
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val a = Accents[acc]
    val cs = if (dark) darkColorScheme(
        primary = lerp(a, Color.White, 0.5f), onPrimary = Color(0xFF0B1220),
        background = Color(0xFF0F1318), surface = Color(0xFF0F1318), onSurface = Color(0xFFE6E9EF),
        onSurfaceVariant = Color(0xFF9AA3B2), surfaceContainer = Color(0xFF1A2029),
        surfaceVariant = Color(0xFF273040), primaryContainer = Color(0xFF26324A), onPrimaryContainer = Color.White,
        outlineVariant = Color(0xFF334055), error = Color(0xFFFF8A80)
    ) else lightColorScheme(
        primary = a, onPrimary = Color.White,
        background = Color(0xFFF3F6FC), surface = Color(0xFFF3F6FC), onSurface = Color(0xFF14181F),
        onSurfaceVariant = Color(0xFF5B6575), surfaceContainer = Color.White,
        surfaceVariant = Color(0xFFE3EAF8), primaryContainer = Color(0xFFDCE6FB), onPrimaryContainer = Color(0xFF0B1B3F),
        outlineVariant = Color(0xFFD5DCEA), error = Color(0xFFB3261E)
    )
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * fs)) {
        MaterialTheme(colorScheme = cs, content = content)
    }
}

@Composable
fun ScreenTitle(text: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Filled.KeyboardArrowLeft, "Atrás") }
        Text(text, fontSize = 28.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun GCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    val col = MaterialTheme.colorScheme.surfaceContainer
    if (onClick != null) Surface(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = shape, color = col) {
        Column(Modifier.padding(16.dp), content = content)
    } else Surface(modifier = modifier.fillMaxWidth(), shape = shape, color = col) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun Note(text: String, warn: Boolean = false) {
    Surface(shape = RoundedCornerShape(16.dp),
        color = if (warn) MaterialTheme.colorScheme.error.copy(alpha = 0.12f) else MaterialTheme.colorScheme.primaryContainer) {
        Text(text, Modifier.padding(12.dp).fillMaxWidth(), fontSize = 13.sp,
            color = if (warn) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun Chip(text: String, sel: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, label = "chip")
    Surface(onClick = onClick, shape = RoundedCornerShape(50), color = bg,
        contentColor = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface) {
        Text(text, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 13.sp)
    }
}

@Composable
fun <T> Choice(title: String, labels: List<String>, values: List<T>, cur: T, onSel: (T) -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            labels.forEachIndexed { i, l -> Chip(l, values[i] == cur) { onSel(values[i]) } }
        }
    }
}

@Composable
fun IntPref(title: String, labels: List<String>, values: List<Int>, key: String, def: Int, after: () -> Unit = {}) {
    var v by remember(key) { mutableStateOf(Prefs.int(key, def)) }
    Choice(title, labels, values, v) { v = it; Prefs.put(key, it); after() }
}

@Composable
fun StrPref(title: String, labels: List<String>, values: List<String>, key: String, def: String) {
    var v by remember(key) { mutableStateOf(Prefs.str(key, def)) }
    Choice(title, labels, values, v) { v = it; Prefs.put(key, it) }
}

@Composable
fun SwitchRow(title: String, desc: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            if (desc != null) Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
fun SwitchPref(title: String, desc: String?, key: String, def: Boolean, enabled: Boolean = true, after: (Boolean) -> Unit = {}) {
    var v by remember(key) { mutableStateOf(Prefs.bool(key, def)) }
    SwitchRow(title, desc, v, enabled) { v = it; Prefs.put(key, it); after(it) }
}

@Composable
fun KV(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(k, Modifier.weight(0.42f), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, Modifier.weight(0.58f), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun Tile(title: String, value: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    GCard(modifier, onClick) {
        Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun BigButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth()) { Text(text) }
}

@Composable
fun SectionLabel(t: String) {
    Text(t, Modifier.padding(top = 8.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
}

@Composable
fun LineChart(v: List<Float>, max: Float, color: Color, modifier: Modifier = Modifier.fillMaxWidth().height(70.dp)) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        drawLine(grid, Offset(0f, size.height), Offset(size.width, size.height), 2f)
        if (v.size > 1) {
            val p = Path()
            v.forEachIndexed { i, y ->
                val x = size.width * i / (v.size - 1)
                val yy = size.height * (1 - (y / max).coerceIn(0f, 1f))
                if (i == 0) p.moveTo(x, yy) else p.lineTo(x, yy)
            }
            drawPath(p, color, style = Stroke(width = 4f))
        }
    }
}

@Composable
fun <T> poll(ms: Long, init: T, block: suspend () -> T): State<T> =
    produceState(init) {
        while (true) {
            value = try { withContext(Dispatchers.IO) { block() } } catch (e: Throwable) { value }
            delay(ms)
        }
    }

@Composable
fun NavBar(sel: Int, onSel: (Int) -> Unit) {
    val items = listOf(
        Icons.Filled.PlayArrow to "Juegos", Icons.Filled.Menu to "Apps", Icons.Filled.Build to "Ajustes",
        Icons.Filled.Info to "Monitor", Icons.Filled.Settings to "Config"
    )
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceContainer, shadowElevation = 8.dp) {
            Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items.forEachIndexed { i, (ic, lb) ->
                    val s = i == sel
                    val bg by animateColorAsState(if (s) MaterialTheme.colorScheme.primary else Color.Transparent, label = "nav")
                    Surface(onClick = { onSel(i) }, shape = CircleShape, color = bg) {
                        Icon(ic, lb, Modifier.padding(14.dp).size(22.dp),
                            tint = if (s) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
