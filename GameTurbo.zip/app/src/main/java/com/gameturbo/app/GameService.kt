package com.gameturbo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/**
 * Servicio en primer plano: detecta cuándo abres un juego de tu lista, aplica las
 * optimizaciones de sesión (vía Shizuku), muestra el panel flotante y lo restaura todo al salir.
 */
class GameService : Service() {
    companion object {
        const val CH = "gt_service"
        const val CH_ALERT = "gt_alert"
        const val ACT_OVERLAY = "overlay"
        @Volatile var running = false
        fun start(c: Context) = ContextCompat.startForegroundService(c, Intent(c, GameService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, GameService::class.java)) }
        fun toggleOverlay(c: Context) =
            ContextCompat.startForegroundService(c, Intent(c, GameService::class.java).setAction(ACT_OVERLAY))
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var overlay: NeonOverlay? = null

    private val fg by lazy { FgTracker(this) }
    private val cpu = CpuSampler()
    private val fps = FpsSampler()
    @Volatile private var active: String? = null
    @Volatile private var applied: String? = null
    @Volatile private var manual = false
    @Volatile private var hidden = false
    private var miss = 0
    private var sat = 100
    private var limitedApplied = emptyList<String>()
    private var lastAlert = 0L
    private var fpsVal: Int? = null
    private var cpuVal: Int? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Game Turbo activo", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Alertas de temperatura", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat).setContentTitle("Game Turbo")
            .setContentText("Vigilando tus juegos").setContentIntent(open).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        scope.launch {
            var t = 0
            while (isActive) {
                try { step(t++) } catch (e: Throwable) { }
                delay(1000)
            }
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACT_OVERLAY) { manual = !manual; hidden = false; ui.post { refreshOverlay() } }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        Thread { endGame() }.start()
        ui.post { hidePanel() }
        super.onDestroy()
    }

    // ---------------- lógica ----------------
    private fun step(t: Int) {
        if (t % 3 == 0 && Perms.usage(this)) detect()
        val b = SysInfo.battery(this)
        val pkg = active
        if (pkg != null) {
            val d = desiredMode(pkg, b)
            if (d != null && d != applied) {
                Ops.setGameMode(pkg, d, Prefs.g(pkg, "scale", 100), Prefs.g(pkg, "fps", 0))
                applied = d
            }
        }
        if (Prefs.bool("a.alerts", true) && b.temp >= Prefs.int("a.alertT", 42) &&
            System.currentTimeMillis() - lastAlert > 300_000
        ) {
            lastAlert = System.currentTimeMillis()
            val n = Notification.Builder(this, CH_ALERT).setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Temperatura elevada").setContentText("Batería a ${b.temp} °C. Considera pausar la partida.").build()
            getSystemService(NotificationManager::class.java).notify(2, n)
        }
        if (overlay != null) {
            cpuVal = cpu.sample() ?: cpuVal
            if (pkg != null && t % 2 == 0) fpsVal = fps.sample(pkg)
            val (rt, ra) = SysInfo.ram(this)
            val mode = if (pkg != null) (applied ?: Prefs.gStr(pkg, "mode", "performance")) else Prefs.str("def.mode", "performance")
            val st = OvStats(
                fpsVal, cpuVal, (100 - ra * 100 / rt).toInt(), b.temp, b.level, mode,
                if (pkg != null) Prefs.g(pkg, "scale", 100) else 100,
                if (pkg != null) Prefs.g(pkg, "fps", 0) else 0, pkg != null
            )
            ui.post { overlay?.update(st) }
        }
    }

    private fun desiredMode(pkg: String, b: SysInfo.Batt): String? {
        if (!Prefs.bool("o.perf", true)) return null
        val m = Prefs.gStr(pkg, "mode", "performance")
        val screenOff = !getSystemService(PowerManager::class.java).isInteractive
        val eco = (Prefs.bool("a.ecoScreen", true) && screenOff) ||
            (Prefs.bool("a.ecoLow", true) && b.level <= Prefs.int("a.lowLvl", 15) && b.plugged == 0)
        if (eco) return "battery"
        if (m == "performance" && Prefs.bool("a.hot", true) && b.temp >= Prefs.int("a.hotT", 44)) return "standard"
        return m
    }

    private fun detect() {
        val cur = fg.update()
        val a = active
        if (cur != null && cur != a && cur in Prefs.games()) { if (a != null) endGame(); startGame(cur) }
        else if (a != null && cur != a && cur != packageName) { if (++miss >= 2) endGame() }
        else miss = 0
    }

    private fun startGame(pkg: String) {
        active = pkg; applied = null; miss = 0; hidden = false; fpsVal = null
        if (Prefs.bool("o.saver", true)) Ops.saverOff()
        if (Prefs.bool("o.clean", true)) Ops.clean()
        if (Prefs.bool("o.bg", false)) {
            limitedApplied = Prefs.limited().filter { it != pkg && it != packageName }
            limitedApplied.forEach { Ops.limitBg(it, true) }
        }
        if (Prefs.bool("o.fixed", false)) Ops.fixed(true)
        sat = Prefs.g(pkg, "sat", 100)
        if (sat != 100) Ops.saturation(sat / 100f)
        ui.post { refreshOverlay() }
    }

    private fun endGame() {
        val pkg = active ?: return
        active = null
        if (applied != null) Ops.resetGame(pkg)
        applied = null
        limitedApplied.forEach { Ops.limitBg(it, false) }
        limitedApplied = emptyList()
        if (Prefs.bool("o.fixed", false)) Ops.fixed(false)
        if (sat != 100) Ops.saturation(1f)
        ui.post { refreshOverlay() }
    }

    // ---------------- panel flotante ----------------
    private fun refreshOverlay() {
        val want = ((active != null && Prefs.bool("ov.on", true)) || manual) && !hidden
        if (want) showPanel() else hidePanel()
    }

    private fun showPanel() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        overlay = NeonOverlay(
            this,
            onClean = { scope.launch { Ops.clean() } },
            onMode = { cycleMode() },
            onScale = { cycleScale() },
            onFps = { cycleFps() },
            onHide = { manual = false; hidden = true; refreshOverlay() }
        ).also { it.show() }
    }

    private fun hidePanel() { overlay?.destroy(); overlay = null }

    private fun cycleMode() {
        val p = active ?: return
        val order = listOf("performance", "standard", "battery")
        val n = order[(order.indexOf(Prefs.gStr(p, "mode", "performance")) + 1) % 3]
        Prefs.put("g.$p.mode", n)
        applied = null
    }

    private fun cycleScale() {
        val p = active ?: return
        val o = listOf(100, 90, 80, 70, 60)
        Prefs.put("g.$p.scale", o[(o.indexOf(Prefs.g(p, "scale", 100)) + 1) % o.size])
        applied = null
    }

    private fun cycleFps() {
        val p = active ?: return
        val o = listOf(0, 30, 45, 60, 90)
        Prefs.put("g.$p.fps", o[(o.indexOf(Prefs.g(p, "fps", 0)) + 1) % o.size])
        applied = null
    }
}
